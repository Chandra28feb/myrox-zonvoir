#!/bin/bash
php artisan migrate --force

php artisan optimize:clear

php artisan config:clear
