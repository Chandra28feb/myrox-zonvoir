<?php

namespace App\Enums;

enum UserType:string {
    case ADMIN = 'Admin';
    case SUPER_ADMIN = 'Super-Admin';
}
