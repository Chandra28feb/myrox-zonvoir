<?php

namespace App\Exceptions;

use Exception;

class SmsException extends Exception
{
    public function __construct($message, $code) {
        parent::__construct($message, $code);
    }

    public function getStatusCode() {
        return $this->code;
    }
}
