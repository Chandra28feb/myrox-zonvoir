<?php
namespace App\Facades;

use Illuminate\Support\Facades\Facade;

class SmsOtp extends Facade {
    /**
     * Class Goal.
     * @method static getAll()
     * @method static getById(int $id)
     *
     */
    protected static function getFacadeAccessor()
    {

        return 'sms-otp';
    }
}
