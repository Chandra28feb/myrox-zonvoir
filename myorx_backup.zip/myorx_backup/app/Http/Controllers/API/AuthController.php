<?php

namespace App\Http\Controllers\API;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Throwable;
use Validator;
use Log;
use App\Models\User;
use App\Facades\SmsOtp;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use App\Jobs\SendEmailCodeJob;

class AuthController extends Controller
{
    /**
     * login
     * user login
     * @param  mixed $request
     * @return void
     */
    public function login(Request $request)
    {
        try {
            $validateUser = Validator::make($request->all(), [
                'email' => ['required', 'string', 'email'],
                'password' => ['required', 'string'],
            ]);

            if ($validateUser->fails()) {
                return response()->json([
                    'message' => __('errors.validation_failed.message'),
                    'errors' => $validateUser->errors()
                ], 400);
            }
            // check email in database
            $user = User::where('email', $request->email)->first();

            if (empty($user)) {
                return response()->json([
                    'message' => __('errors.authentication_failed.message'),
                    'errors' => ['email' => __('auth.failed')]
                ], 400);
            }

            if($user->is_mobile_verified==0){
                SmsOtp::OtpMessages($user->mobile_no);
            } else if($user->is_email_verified==0){
                $userData['first_name'] = $user->first_name;
                $userData['last_name'] = $user->last_name;
                $userData['email'] = $user->email;
                SendEmailCodeJob::dispatch($userData);
            }

            if (!auth()->attempt($request->only(['email', 'password']))) {
                //LoginLogs::log($user->id, LogStatus::ERROR);
                return response()->json([
                    'message' => __('errors.invalid_credentials.message'),
                    'errors' => ['email' => __('auth.failed')]
                ], 400);
            }
            // update user last activity to db
            $user->update(['last_activity' => now()->toDateTimeString()]);
            //LoginLogs::log($user->id);
            $apiToken = $request->user()->createToken("AUTH TOKEN", [], now()->addHours(2))->plainTextToken;
            $userRole =  $user->getRoleNames();
            $success  = ['token'=> $apiToken, 'user'=> $user];
            return response()->json([
                'message' => __('response.authentication_success'),
                'userRole'=>$userRole,
                'success' =>$success
            ],200);
        }catch(Throwable $e){
            return response()->json([
                'message' => $e->getMessage(),
                'errors' => __('errors.server_error')
            ], 500);
        }
    }
    /**
     * verifyToken
     * verify auth token to db
     * @param  mixed $request
     * @return void
     */
    public function verifyToken(Request $request)
    {
        try {
            $bearerToken = $request->header('Authorization');
            $tokenId = explode('|', explode(' ', $bearerToken)[1])[0]; // extract the id from token
            $token = $request->user()->tokens()->where('id', $tokenId)->first();
            if (now()->greaterThanOrEqualTo(Carbon::parse($token['expires_at']))) {
                // $token->delete();
                return response()->json([
                    'message' => __('errors.unauthorized.message'),
                    'errors' => __('errors.auth_token_expired')
                ], 401);
            }

            return response()->json([
                'message' => __('response.auth_token_valid'),
            ], 200);

        } catch (Throwable $e) {
            Log::error($e->getMessage());
            return response()->json([
                'message' => $e->getMessage(),
                'errors' => __('errors.server_error')
            ], 500);
        }
    }
    public function logout(Request $request)
    {
        if(!empty(Auth::user()->currentAccessToken())){
            if($request->user()->currentAccessToken()->delete()){
                return  response()->json(['message'=>__('response.user_logout_success')],200);
            }
            else {
                return  response()->json(['message'=>__('response.user_logout_failed')],400);
            }
        }
        else {
            return  response()->json(['message'=>__('response.user_unauthenticated')],400);
        }
    }

}
