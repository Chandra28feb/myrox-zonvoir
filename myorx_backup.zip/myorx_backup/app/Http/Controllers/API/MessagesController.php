<?php

namespace App\Http\Controllers\API;

use Throwable;
use App\Facades\SmsOtp;
use Illuminate\Http\Request;
use App\Jobs\SendEmailCodeJob;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Log;
use Twilio\Rest\Client;
use App\Models\User;

class MessagesController extends Controller
{
    /**
     * __construct
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('auth');
    }
    /**
     * sendOtpMessage
     *  send otp to mobile
     * @param  mixed $request
     * @return void
     */
    public function sendOtpMessage(Request $request){
        try{
            $user = auth()->user();
            return SmsOtp::OtpMessages($user->mobile_no);
        }catch(Throwable $e){
            return response()->json([
                'message' => $e->getMessage(),
                'errors' => __('errors.server_error')
            ], 500);
        }
    }
    /**
     * otpVerify
     * verify mobile otp
     * @param  mixed $request
     * @return void
     */
    public function otpVerify(Request $request){
        try{
            $user = auth()->user();
            return SmsOtp::VerifyOtp($user,$request);
        }catch(Throwable $e){
            return response()->json([
                'message' => $e->getMessage(),
                'errors' => __('errors.server_error')
            ], 500);
        }


    }
    /**
     * sendEmailMessage
     * send otp on email
     * @param  mixed $request
     * @return void
     */
    public function sendEmailMessage(Request $request){
        try {
            $user = auth()->user();
            $userData['first_name'] = $user->first_name;
            $userData['last_name'] = $user->last_name;
            $userData['email'] = $user->email;
            SendEmailCodeJob::dispatch($userData);
            return response()->json(['success' => __('response.email_process'),'email'=>$user->email], 200);
        } catch (Throwable $e) {
            Log::error($e->getMessage());
            return response()->json([
                'message' => $e->getMessage(),
                'errors' => __('errors.server_error')
            ], 500);
        }

    }
    /**
     * emailVerify
     * verify email otp
     * @param  mixed $request
     * @return void
     */
    public function emailVerify(Request $request){
        try {
            $user = auth()->user();
            $account_sid = \Config::get('services.twilio.sid');
            $account_token = \Config::get('services.twilio.auth_token');
            $account_verify_sid = \Config::get('services.twilio.verify_sid');

            $twilio_client = new Client($account_sid, $account_token);
            
            $verification = $twilio_client->verify->v2->services($account_verify_sid)
                ->verificationChecks
                ->create(["to" =>$user->email,"code" => $request->verification_code]); 
        
            if (isset($verification) && $verification->valid) {
                $user->update(['is_email_verified' => true,'email_verified_at'=> now()]);
                $success['is_email_verified'] = User::find($user->id)->is_email_verified;
                return response()->json(['message'=> __('message.email.verified'),'success' => $success], 200);
            } else {
                return response(['error' => __('errors.email.invalid_verification_code'),'message'=> __('errors.email.invalid_verification_code'),],400);
            }
        
        }catch (Throwable $e) {
            Log::error($e->getMessage());
            return response()->json([
                'message' => $e->getMessage(),
                'errors' => __('errors.server_error')
            ], 500);
        }
    }
}
