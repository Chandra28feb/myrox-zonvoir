<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Rules\PhoneNumberLookupRule;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rules\Password;
use App\Models\User;
use Throwable;
use App\Services\Twilio\PhoneNumberLookupService;
use Illuminate\Support\Facades\Auth;

class RegisterController extends Controller
{

    /**
     * Registration Req
     */
    public function signup(Request $request)
    {
        try{
            $validator = Validator::make($request->all(), [
                'first_name' => ['required','string','max:30'],
                'last_name'  => ['required','string','max:30'],
                'email'      => ['required','email','unique:users'],
                'mobile_no'  => ['required','unique:users',new PhoneNumberLookupRule()],
                // 'referred_by'=> ['required'],
                'password'   => ['required',Password::min(8)->letters()->mixedCase()->numbers()->symbols()->uncompromised()]
            ]);
            if ($validator->fails()) {
            return response(['error' => $validator->errors()],401);
            }

            $user = User::create([
                'first_name' => trim($request->first_name),
                'last_name' => trim($request->last_name),
                'email'     => trim($request->email),
                'mobile_no' => $request->mobile_no,
                'referred_by' => $request->referred_by ?? null,
                'password' => bcrypt($request->password)
            ]);
            $user->assignRole('Patient');
            $success['token'] = $user->createToken("AUTH TOKEN")->plainTextToken;
            $success['user'] = User::find($user->id);
            $credentials = $request->only('email','password');
            if (Auth::attempt($credentials)) {
                $userRole =  auth()->user()->getRoleNames();
                return response()->json(['success' => $success,'userRole'=>$userRole,], 200);
            }
        }catch(Throwable $e){
            return response()->json([
                'message' => $e->getMessage(),
                'errors' => __('errors.server_error')
            ], 500);
        }

    }
}
