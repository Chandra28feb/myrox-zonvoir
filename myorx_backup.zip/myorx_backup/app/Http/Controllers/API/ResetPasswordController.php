<?php

namespace App\Http\Controllers\API;
use App\Models\User;
use App\Mail\Auth\ForgetPasswordMail;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Password;
use Illuminate\Auth\Events\PasswordReset;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rules\Password as ValPassword;
use Throwable;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use App\Jobs\SendResetPasswordLinkJob;
class ResetPasswordController extends Controller
{
    public function forgetPassword(Request $request)
    {
        try{
            $validator = Validator::make($request->all(), [
                'email'      => ['required','email'],
            ]);
            if ($validator->fails()) {
                return response(['error' => $validator->errors()],400);
            }
            $user = User::where('email', $request->email)->first();

            if (empty($user)) {
                return response()->json([
                    'message' => __('passwords.user'),
                    'errors' => ['email' => __('passwords.user')]
                ], 400);
            }

            $token = app('auth.password.broker')->createToken($user);
            $notificationData = [
                'email'=>$request->email,
                'token'=>$token,
                'first_name'=>$user->first_name,
                'last_name'=>$user->last_name,
                'url'=> route('password.update')
            ];
            SendResetPasswordLinkJob::dispatch($notificationData);
            return response()->json(['success' => __('response.reset_link_send'),'email'=>$user->email], 200);
            // Mail::to($request->email)->send(new ForgetPasswordMail($notificationData));

        }catch(Throwable $e){
            Log::error($e->getMessage());
            return response()->json([
                'message' => $e->getMessage(),
                'errors' => __('errors.server_error')
            ], 500);
        }
    }
    public function resetPassword(Request $request)
    {
        try{
            $validator = Validator::make($request->all(), [
                'email'      => ['required','email'],
                'token' => ['required'],
                'password'   => ['required','confirmed',ValPassword::min(8)->letters()->mixedCase()->numbers()->symbols()->uncompromised()]
            ]);

            if ($validator->fails()) {
                return response(['error' => $validator->errors()],400);
            }
            $status = Password::reset(
                $request->only('email','password', 'password_confirmation', 'token'),
                function (User $user, string $password) {
                    $user->forceFill([
                        'password' => bcrypt($password)
                    ])->setRememberToken(Str::random(60));
                    $user->save();
                    event(new PasswordReset($user));
                }
            );
            $status === Password::PASSWORD_RESET
            ? response()->json(['message' => __('passwords.reset')], 200)
            : response()->json(['error' => __('passwords.reset_failed')], 400);
        }catch(Throwable $e){
            Log::error($e->getMessage());
            return response()->json([
                'message' => $e->getMessage(),
                'errors' => __('errors.server_error')
            ], 500);
        }
    }
}
