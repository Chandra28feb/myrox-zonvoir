<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Interfaces\UserRepositoryInterface;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
class UserController extends Controller
{
    private UserRepositoryInterface $userRepository;

    public function __construct(UserRepositoryInterface $userRepository)
    {
        $this->userRepository = $userRepository;
    }

    public function changeMobileNumber(Request $request)
    {
        $validateUser = Validator::make($request->all(), [
            'mobile_no' => ['required'],
        ]);

        if ($validateUser->fails()) {
            return response()->json([
                'message' => __('errors.validation_failed_mobile.message'),
                'errors' => $validateUser->errors()
            ], 400);
        }

        if($this->userRepository->updateMobile(auth()->user()->id, $request->mobile_no)){
            return  response()->json(['message'=>__('response.phone_change_success')],200);
        }
        else {
            return  response()->json(['message'=>__('response.phone_change_limit_breach')],400);
        }

    }
    public function changeEmailAddress(Request $request)
    {
        $validateUser = Validator::make($request->all(), [
            'email' => ['required'],
        ]);

        if ($validateUser->fails()) {
            return response()->json([
                'message' => __('errors.validation_failed_email.message'),
                'errors' => $validateUser->errors()
            ], 400);
        }
        if($this->userRepository->updateEmail(auth()->user()->id, $request->email)){
            return  response()->json(['message'=>__('response.email_change_success')],200);
        }
        else {
            return  response()->json(['message'=>__('response.email_change_failed')],400);
        }
    }


}
