<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Auth;
use App\Models\User;

class ChangeMobileNumber
{

    public function handle(Request $request, Closure $next): Response
    {
        $result = User::where('id',auth()->user()->id)->pluck('is_phone_changed')->first();
        if($result == 1){
            return  response()->json(['message'=>__('response.phone_change_limit_breach')],400);
        }
        return $next($request);

    }
}
