<?php

namespace App\Interfaces;

interface UserRepositoryInterface {
    public function updateUser(string $userId, Array $userData);

    public function updateMobile(string $userId, string $mobileNo);
    public function updateEmail(string $userId, string $email);
}
