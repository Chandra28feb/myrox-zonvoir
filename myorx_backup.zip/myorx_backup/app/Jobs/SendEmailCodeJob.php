<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Twilio\Rest\Client;
use Illuminate\Support\Facades\Log;

class SendEmailCodeJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;
    protected $data;
    /**
     * Create a new job instance.
     */
    public function __construct($data)
    {
        $this->data = $data;
    }

    /**
     * Execute the job.
     */
    public function handle(): void
    {
        $account_sid = \Config::get('services.twilio.sid');
        $account_token = \Config::get('services.twilio.auth_token');
        $account_verify_sid = \Config::get('services.twilio.verify_sid');
        $twilio_client = new Client($account_sid, $account_token);
        $emailData = [
            'account_username' => $this->data['first_name'] . ' ' . $this->data['last_name'],
            'year' => now()->format('Y')
        ];
        try {
            $twilio_client->verify->v2->services($account_verify_sid)->verifications->create(
                $this->data['email'], 'email',
                [
                    "channelConfiguration" => [
                        "substitutions" => $emailData
                    ] 
                ]
            );
        } catch (\Throwable $e) {
            \Log::error(json_encode($e->getMessage()));
        }
    }
}