<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Twilio\Rest\Client;
use Illuminate\Support\Facades\Log;

class SendResetPasswordLinkJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    protected $notificationData;

    public function __construct($notificationData)
    {
        $this->notificationData = $notificationData;
    }

    public function handle(): void
    {
        $account_sid = \Config::get('services.twilio.sid');
        $account_token = \Config::get('services.twilio.auth_token');
        $account_verify_sid = \Config::get('services.twilio.verify_sid');
        $twilio_client = new Client($account_sid, $account_token);
        $emailData = [
            'account_username' => $this->notificationData['first_name'] . ' ' . $this->notificationData['last_name'],
            'url' => $this->notificationData['url'],
            'email'=>$this->notificationData['email'],
            'token'=>$this->notificationData['token']
        ];
        try {
            $twilio_client->verify->v2->services($account_verify_sid)->verifications->create(
                $this->data['email'], 'email',
                [
                    "channelConfiguration" => [
                        "substitutions" => $emailData
                    ] 
                ]
            );
        } catch (\Throwable $e) {
            \Log::error(json_encode($e->getMessage()));
        }
    }
}
