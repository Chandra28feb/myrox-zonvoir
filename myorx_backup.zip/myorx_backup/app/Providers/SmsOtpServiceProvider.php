<?php
namespace App\Providers;
use Illuminate\Support\ServiceProvider;
use App\Services\SmsOtpService;
use App;

class SmsOtpServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     */
    public function register(): void
    {
        App::bind('sms-otp', function() {
            return new SmsOtpService;
        });
    }

    /**
     * Bootstrap services.
     */
    public function boot(): void
    {
        //
    }
}
