<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use App\Services\Twilio\PhoneNumberLookupService;

class TwilioLookupServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     */
    public function register(): void
    {
        $this->app->singleton(PhoneNumberLookupService::class, function ($app) {
           return new PhoneNumberLookupService(
            config('services.twilio.sid'),
            config('services.twilio.auth_token')
            );
        });
    }

    /**
     * Bootstrap services.
     */
    public function boot(): void
    {
        //
    }
}
