<?php
namespace App\Repositories;

use App\Interfaces\UserRepositoryInterface;
use App\Models\User;

class UserRepository implements UserRepositoryInterface {

    public function updateEmail(string $userId, string $email) {
        return $this->updateUser($userId, ['email' => $email, 'is_email_changed' => true]);
    }

    public function updateMobile(string $userId, string $mobileNo) {
        return $this->updateUser($userId, ['mobile_no' => $mobileNo, 'is_phone_changed' => true]);
    }

    public function updateUser(string $userId, Array $userData) {
        $user = User::where('id', $userId)->first();
        return $user->update($userData);
    }
}
