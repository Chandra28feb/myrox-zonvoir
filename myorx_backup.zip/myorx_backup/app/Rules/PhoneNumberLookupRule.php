<?php

namespace App\Rules;

use Closure;
use Illuminate\Contracts\Validation\Rule;
use App\Services\Twilio\PhoneNumberLookupService;

class PhoneNumberLookupRule implements Rule
{
   /**
     * Create a new rule instance.
     *
     * @return void
     */
    private $service;

    public function __construct() {
        $lookupService = new PhoneNumberLookupService(
            config('services.twilio.sid'),
            config('services.twilio.auth_token')
            );
        $this->service = $lookupService;
    }
    public function passes($attribute, $value)
    {
        return $this->service->validate($value);
    }
    /**
     * Get the validation error message.
     *
     * @return string
     */
    public function message()
    {
        return __('errors.validation.phone_number_invalid');
    }
}
