<?php
namespace App\Services;
use App\Models\User;
// use Twilio\Exceptions\TwilioException;
use Twilio\Rest\Client;
use App\Exceptions\SmsException;
use Twilio\Exceptions\RestException;

class SmsOtpService {
    protected $token;
    protected $twilio_sid;
    protected $twilio_verify_sid;
    /**
     * Create a new SmsOtpService instance.
     */
    public function __construct()
    {
        $this->token = config('services.twilio.auth_token');
        $this->twilio_sid = config('services.twilio.sid');
        $this->twilio_verify_sid = config('services.twilio.verify_sid');
    }
    /**
     * OtpMessages
     * create otp from twilio services
     * @param  mixed $mobile_no
     * @return void
     */
    public function OtpMessages($mobile_no)
    {
        try {
            $twilio = new Client($this->twilio_sid, $this->token);
            $twilio->verify->v2->services($this->twilio_verify_sid)->verifications->create('+1'.$mobile_no, "sms");
            return response()->json(['message'=>__('message.phone_otp.send'),'mobile_no'=>$mobile_no], 200);
        } catch (RestException $e) {
            throw new SmsException($e->getMessage(), 500);
        }

    }
    /**
     * VerifyOtp
     * verify otp from twilio services
     * @param  mixed $user
     * @param  mixed $data
     * @return void
     */
    public function VerifyOtp($user,$data)
    {
        try {
            $user = auth()->user();
            $twilio = new Client($this->twilio_sid,$this->token);
            $verification = $twilio->verify->v2->services($this->twilio_verify_sid)
                ->verificationChecks
                ->create([
                    "to" => '+1'.$user->mobile_no,
                    "code" => $data->verification_code
                ]);
                if ($verification->valid) {
                    $user->update(['is_mobile_verified' => true,'mobile_verified_at'=> now()]);
                    /* Authenticate user */
                    // dd($user);
                    $success['is_mobile_verified'] = $user->is_mobile_verified;
                    return response()->json(['message'=>__('message.phone_otp.phone_verified'),'success' => $success], 200);
                }
                return response()->json(['message'=>__('message.phone_otp.expired_code'),'errors' => __('errors.server_error')], 403);

        } catch (RestException $e) {
            throw new SmsException($e->getMessage(), 500);
        }
    }
}
