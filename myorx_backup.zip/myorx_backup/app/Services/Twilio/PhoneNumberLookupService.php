<?php

namespace App\Services\Twilio;

use Twilio\Rest\Client;
use Twilio\Exceptions\RestException;

class PhoneNumberLookupService
{
    private $client;

    public function __construct(string $authSID, string $authToken)
    {
        $this->client = new Client($authSID, $authToken);
    }

    public function validate(string $phoneNumber): bool
    {
        if (empty($phoneNumber)) {
            return false;
        }

        try {
            $phone_number = $this->client->lookups->v2->phoneNumbers('+1'.$phoneNumber)->fetch();
            if($phone_number->toArray()['valid']){
                return true;
            }
        } catch (RestException $e) {
            return false;
        }


    return false;
    }
}
