<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;

class PermissionSeeder extends Seeder
{
    public function run(): void
    {
        $data = $this->permissionList();
        foreach ($data as $value) {
            Permission::create(['name'=>$value]);
        }
    }
    public function permissionList()
    {
        return ['User Insert','User Update','User View','User Delete'];
    }
}
