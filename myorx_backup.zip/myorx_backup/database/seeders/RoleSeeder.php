<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;

class RoleSeeder extends Seeder
{

    public function run(): void
    {
        $roles = $this->roleList();
        foreach ($roles as  $value) {
            $role = Role::create(['name'=>$value['name']]);
            $this->assignPermissionRoleWise($value,$role);
        }
    }
    public function roleList()
    {
        return [
            ['name'=>'Admin'],
            ['name'=>'Patient']
        ];
    }
    public function assignPermissionRoleWise($value,$role)
    {
        if($value['name'] == 'Admin'){
            $permissions = Permission::all();
            $role->syncPermissions($permissions);
        }
    }
}
