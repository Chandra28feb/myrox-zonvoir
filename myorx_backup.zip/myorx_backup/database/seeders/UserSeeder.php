<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use App\Models\User;
class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $user = User::create([
            'first_name' => 'tech',
            'last_name' => 'support',
            'email' => 'techsupport@mindyourownrx.com',
            'mobile_no' => '9137886215',
            'password' => bcrypt('test@123'),
        ]);
        $user->assignRole('Admin');
    }
}
