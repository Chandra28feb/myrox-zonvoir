<template>
    <RouterView/>
</template>
<script>
import { RouterView } from "vue-router";
</script>
<style lang="scss">
@import "../scss/globleStyle";
@import "../scss/auth_pages.scss";
@import url("https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap");
html{
    font-family: "Poppins", sans-serif;
}
body{
    font-family: "Poppins", sans-serif;

}
.btn{
    &:disabled{
        opacity: 0.65;
        pointer-events: none;
        background-color: $primary_color;
        border: 1px solid $primary_color;
    }
}
.btn-primary{
    background-color: $primary_color;
    color: $white;
    border: 1px solid $primary_color;
    outline: none;
    border-radius: 4px;
    &:hover{
        background-color: $primary_hover;
        border: 1px solid $primary_color;
        outline: none;
    }
    &:enabled{
        &:active{
            background-color: $primary_hover;
            border: 1px solid $primary_color;
        }
    }
    &:active{
        background-color: $primary_hover;
    }
}
.link-primary{
    color: $primary_color !important;
    font-size: 20px;
    line-height: 24px;
    font-weight: 400;
    text-decoration: none;
    &:hover{
        color: $primary_color !important;
    }
}

.fw-700{
    font-weight: 600;
}
</style>