import "./bootstrap";
import router from "./router/index";
import "bootstrap/dist/css/bootstrap.min.css";
import "vue3-toastify/dist/index.css";
import "vue-tel-input/dist/vue-tel-input.css";

import "bootstrap";
import { library } from "@fortawesome/fontawesome-svg-core";
import { FontAwesomeIcon } from "@fortawesome/vue-fontawesome";
import { faBars } from "@fortawesome/fontawesome-free-solid";
import Vue3Toastify from "vue3-toastify";
import { initVeeValidate } from "@/js/utils/ValidationConfig";
import { createApp } from "vue";
import { createPinia } from "pinia";
import VueTelInput from "vue-tel-input";
import App from "./App.vue";
const globalOptions = {
    mode: "auto",
};
library.add(faBars);
const app = createApp(App);
app.use(createPinia());
app.use(Vue3Toastify, {
    autoClose: 3000,
    position: "bottom-right",
});
initVeeValidate();
app.directive("focus", {
    mounted: function (el) {
        el.focus();
    },
}),
    app.use(VueTelInput, globalOptions);
app.use(router);
app.component("font-awesome-icon", FontAwesomeIcon);
app.mount("#app");
