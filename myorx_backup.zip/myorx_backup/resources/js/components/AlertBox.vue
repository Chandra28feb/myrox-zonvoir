<template>
    <div class="alert alert-danger alert-dismissible fade show alert_box_wrap" role="alert">
        <!-- <strong>Holy guacamole!</strong>  -->
        {{message}}
        <button type="button" class="btn-close alert_close_btn" data-bs-dismiss="alert" aria-label="Close">
            <!-- <font-awesome-icon icon="fa-solid fa-bars" class=""  /> -->
        </button>
      </div>
</template>
<script setup>
const props = defineProps({
    message:{
        type:String,
        default:'Something wrong happened',
    }
})
</script>