<template>
    <div class="header_logo">
        <a href="#"><img  alt="Logo"
            :src="logoImg"
            class="img-responsive"></a>
    </div>
</template>
<script setup>

import { getAssetPath } from "../utils/AssetPath";
    const props = defineProps({
        logoImg:String,
    })

</script>
<style lang="scss" scoped>
.header_logo {
	img {
		height: 40px;
	}
}
</style>