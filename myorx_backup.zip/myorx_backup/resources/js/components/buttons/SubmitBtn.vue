<script setup >
const props = defineProps({
    title:{
        type:String,
        default:'Submit'
    },
    loadingStatus:{
        type:Boolean,
        default:false
    }

})
</script>
<template>
    <button
    type="button"
    class="btn btn-lg btn-primary btn_cus_primary customize_btn w-100"
    
  >
    <span  class="indicator-label"> {{ title }} </span>
    <span  class="indicator-progress">
      Please wait...
      <span
        class="spinner-border spinner-border-sm align-middle ms-2"
      ></span>
    </span>
  </button>
</template>