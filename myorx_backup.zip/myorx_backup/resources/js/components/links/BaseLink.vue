<script setup>
const props = defineProps({
    baseText:{ type:String},
    pageLink:{ type:String},
    linkTitle:{ type:String},
    imgIcon:{ type:String},
})
</script>
<template>
    <div class="d-flex align-items-center base_link_wraper">
        <p v-if="baseText" class="mb-0 ps-1">{{baseText}}</p>
        <router-link :to="`${pageLink}`" class="link-primary">
        {{ linkTitle }}
        <span  class="pl-3 icon_wrap">
            <img v-if="imgIcon" :src="imgIcon"  alt="icon"/>
          </span>
        </router-link>
    
    </div>
</template>