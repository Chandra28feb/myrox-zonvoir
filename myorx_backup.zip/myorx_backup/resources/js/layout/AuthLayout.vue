<template>
  <!--begin::Authentication Layout -->
  <div class="layout_container">
    <Header :is-login-page="checkLoginPage"  :isLogoutVisible="isLogout" />
    <div class="auth_layout_wrapper">
      <router-view></router-view>
    </div>
    <Footer />
  </div>
  <!--end::Authentication Layout -->
</template>

<script setup>
import { checkAuth } from "../utils/common";
import Footer from "./footer/Footer.vue";
import Header from "./header/Header.vue";
import { ref,onUpdated,onMounted } from "vue";
import { useRouter } from "vue-router";
const { hasToken } = checkAuth();
const router = useRouter();
let checkLoginPage = ref(true);
let isLogout = hasToken ? true : false;

onUpdated (()=>{
  if(router.currentRoute._value.name==='register'){
    checkLoginPage.value = true
  } else if(router.currentRoute._value.name==='login'){
    checkLoginPage.value = false
  } else{
    checkLoginPage.value = true
  }
})
onMounted (()=>{
  router.currentRoute._value.name==='register'?checkLoginPage.value = true:checkLoginPage.value = false;
})
</script>
<style lang="scss" scoped></style>
