<template>
    <!--begin::Authentication Layout -->
    <div class="dash_layout_container">
      <Header :isLogoutVisible=isLogout />
      <div class="dash_layout_wrapper">
        <router-view></router-view>
      </div>
      <!-- <Footer /> -->
    </div>
    <!--end::Authentication Layout -->
  </template>
<script setup>
// import Footer from "./footer/Footer.vue";
import router from "../router";
import { checkAuth } from "../utils/common";
import Header from "./header/Header.vue";
const { hasToken, isEmailVerified, isPhoneVerified, userRole } = checkAuth();
isEmailVerified ? '' : router.push({ name: "email-otp"});
isPhoneVerified ? '' : router.push({ name: "phone-otp"});
(userRole === "Patient") ? router.push({name: "patient"}) : router.push({name:"dashboard"});
let isLogout = hasToken ? true : false;
</script>