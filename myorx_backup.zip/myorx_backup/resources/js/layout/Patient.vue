<template>
    <div class="dashboard_wrapper">
        <div class="dash_container">
            <h2>Patient Page</h2>
            <p class="text-center"> coming Soon...</p>
        </div>
    </div>
</template>