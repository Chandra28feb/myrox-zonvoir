<template>
  <div class="footer_panel">
    <!-- <div class="footer_top_sec">
      <div class="global_container">
        <div class="footer_top_menu_wrap">
          <div class="footer_top_first">
            <h3>Expert care made <br />easy and discreet</h3>
            <h5>Subscribe to our weekly newsletter</h5>
            <p>
              We guarantee, we will not send spammy or unwanted stuff. We
              promise!
            </p>

            <div class="input-group subscription_sec">
              <form>
                <input
                  type="text"
                  class="form-control"
                  placeholder="Enter your email"
                />
                <span class="input-group-btn">
                  <button type="button" class="">Subscribe Now</button>
                </span>
              </form>
            </div>
          </div>
          <div class="footer_top_second">
            <h4>Website Links</h4>
            <ul>
              <li><a href="#">Home</a></li>
              <li><a href="#">About Us</a></li>
              <li><a href="#">What We Treat</a></li>
              <li><a href="#">Pricing</a></li>
              <li><a href="#">Contact Us</a></li>
            </ul>
          </div>
          <div class="footer_top_second">
            <h4>Legal</h4>
            <ul>
              <li><a href="#">Privacy Policy</a></li>
              <li><a href="#">Terms and Conditions</a></li>
              <li><a href="#">What We Treat</a></li>
              <li><a href="#">Terms of Use</a></li>
              <li><a href="#">Cookie Policy</a></li>
              <li><a href="#">Telemedicine Consent</a></li>
            </ul>
          </div>
          <div class="footer_top_second">
            <h4>Quick Links</h4>
            <ul>
              <li><a href="#">Patient’s Portal</a></li>
              <li><a href="#">Doctor’s Portal</a></li>
            </ul>
          </div>
          <div></div>
        </div>
      </div>
    </div> -->
    <div class="footer_bottom_sec">
      <div class="global_container">
        <div class="wrap_logo_social">
          <Logo :logoImg="logopic" />
      
          <div class="footer_right_social">
            <div class="wrap_socail_data">
              <div>
                <a href="#">
                  <img :src="facebooklogo" class="img-responsive" alt="Image">
                </a>
              </div>
              <div>
                <a href="#">
                  <img :src="instalogo" class="img-responsive" alt="Image">
                </a>
              </div>
              <div>
                <a href="#" class="linked_in">
                  <img :src="linkedInlogo" class="img-responsive" alt="Image">
                </a>
              </div>
            </div>
          </div>
        </div>

        <div class="footer_copywrite">
          <p>© 2023 myoRx. All Rights Reserved.</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import logopic from "@/assets/custom/myoRX_logo.svg"
import Logo from "../../components/Logo.vue";
import linkedInlogo from "@/assets/custom/linkedIn_white.svg"
import facebooklogo from "@/assets/custom/fb_white.svg"
import instalogo from "@/assets/custom/insta_white.svg"
</script>

<style lang="scss">
$color_1: #1e1e1e;
$color_2: #535353;
$color_3: #52137d;
$color_4: #000000;
$color_5: white;
$font-family_1: "Poppins";
$background-color_1: #f2f5f7;
$background-color_2: #52137d;
$border-color_1: #52137d;
.global_container {
  padding: 0 84px;
}
.footer_top_menu_wrap {
  justify-content: space-between;
  display: flex;
}
.footer_top_first {
  width: 40%;
  h3 {
    font-family: $font-family_1;
    font-style: normal;
    font-weight: 600;
    font-size: 32px;
    color: $color_3;
    line-height: 40px;
    margin-bottom: 10px;
  }
  h5 {
    font-weight: 400;
    font-size: 24px;
    line-height: 28px;
    letter-spacing: -1px;
    color: $color_4;
    margin: 0;
  }
  p {
    font-weight: 400;
    font-size: 18px;
    line-height: 30px;
    color: $color_4;
    margin: 13px 0;
  }
}
.footer_top_sec {
  background-color: $background-color_1;
  padding: 30px 0;
}
.footer_top_second {
  h4 {
    font-family: $font-family_1;
    font-style: normal;
    font-weight: 600;
    font-size: 18px;
    color: $color_1;
    margin-bottom: 20px;
  }
  ul {
    padding: 0;
    li {
      display: inherit;
      margin-bottom: 15px;
      a {
        font-family: $font-family_1;
        font-style: normal;
        font-weight: 400;
        font-size: 16px;
        color: $color_2;
        text-decoration: none;
        &:hover {
          color: $color_3;
        }
      }
    }
  }
}
.subscription_sec {
  input {
    padding: 10px;
    width: 290px;
    height: 50px;
    border: 1px solid #dfdfdf;
    font-size: 18px;
    outline: 0 !important;
    box-shadow: inherit;
  }
  button {
    border: 1px solid #52137d;
    margin-left: 10px;
    padding: 13px 12px;
    background-color: $background-color_2;
    color: $color_5;
    text-decoration: none;
    font-weight: 600;
    height: 49px;
    font-size: 13px;
    text-transform: uppercase;
    font-family: $font-family_1;
    cursor: pointer;
  }
  form {
    display: flex;
  }
}
.footer_bottom_sec {
  background-color: $background-color_2;
  padding: 50px 0;
}
.wrap_logo_social {
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-bottom: 1px solid white;
}
.wrap_socail_data {
  display: flex;
  justify-content: flex-end;
  a {
    margin-left: 20px;
    &.linked_in {
      i {
        width: 30px;
        height: 30px;
        background-color: #fff;
        line-height: 30px;
        text-align: center;
        font-size: 20px;
        border-radius: 50%;
        color: #52137d;
      }
    }
    i {
      text-align: center;
      font-size: 30px;
      color: #fff;
    }
  }
}
.footer_copywrite {
  p {
    margin: 0;
    text-align: center;
    color: $color_5;
    padding-top: 16px;
    font-size: 16px;
  }
}
.hide_desktop {
  display: none;
}
.input-group {
  .btn {
    border-radius: 0 !important;
  }
}
.form-control {
  border-radius: 0 !important;
  &:focus {
    border-color: $border-color_1 !important;
    outline: 0 !important;
    box-shadow: inherit !important;
  }
}
.wrap_mobile_ipad_menu {
  z-index: 9999;
}
/* Responsive  */

/*Mobile*/
@media (max-width:767px) {
  .footer_top_first {
    h3{
    font-size: 28px;
    line-height: 30px;
  }
  h5{
    font-size: 22px;
    line-height: 26px;
  }
}
}
</style>
