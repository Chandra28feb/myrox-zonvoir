<template>
  <div class="header_panel hide_mobile_ipad">
    <div class="global_container">
      <div class="wrap_header_data">
        <!--Left-->
        <div class="header_left">
          <div class="head_left_box">
          <div class="menu_btn_wrap">
            <button @click="openSidebar" class="btn icon_button">
              <font-awesome-icon icon="fa-solid fa-bars" class=""  />
            </button>
          </div>
          <div class="ci_logo_wrap">
            <Logo :logoImg="logopic" />
          </div>
        </div>
        </div>
        <!--Center-->
        <div class="header_center">
        </div>
        <!--Right-->
        <div class="header_right">
          <div v-if="isLogoutVisible" class="logout_btn">
            <button @click="logoutHandler" class="btn btn-outline-primary">Logout</button>
          </div>
          <div v-else class="header_right_side_button">
            <div v-if="isLoginPage" class="login_btn">
              <router-link to="/login" class="">Login</router-link>
            </div>
            <div v-else class="login_btn">
              <router-link to="/register" class="">Register</router-link>
            </div>
            <div class="see_doctor">
              <a href="#">See A Doctor</a>
            </div>
          </div>
        
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import logopic from "@/assets/custom/myoRX-logo-prime.svg"
import Logo from "@/js/components/Logo.vue";
import ApiBase from "@/js/services/ApiBase";
import { destroyToken } from "@/js/services/Jwt";
import { logoutUser } from "@/js/utils/sendOTP";
import { onMounted,onUpdated, ref} from 'vue';
import { useRouter } from "vue-router";
const router = useRouter();
const props = defineProps({
  isLoginPage:{
    type:Boolean,
    default:false,
  },
  isLogoutVisible:{
    type:Boolean,
    default:false,
  },
})
const openSidebar = ()=>{
  console.log("openSidebar");
}
 const logoutHandler = () =>{
  destroyToken();
  router.push({ name: "login" });
  // logoutUser()
  }

</script>

<style lang="scss">
@import "@/scss/globleStyle";


/****dropdown***/
/****close dropdown***/
.global_container {
  padding: 0 84px;
}
.wrap_header_data {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.header_left {
  width: 15%;
}
.header_center {
  width: 60%;
}
.header_right {
  width: 25%;
  text-align: right;
}
.header_logo {
  img {
    height: 40px;
  }
}
.top_level_menu {
  a {
    text-decoration: none;
    font-weight: 500;
    font-size: 16px;
    text-transform: uppercase;
    color: $dark;
    padding: 15px 0;
  }
  li {
    margin-right: 25px;
    &:hover {
      > ul {
        display: inline;
      }
    }
    a {
      &:hover {
        border-bottom: 2px solid $primary_color;
        color: $primary_color;
      }
    }
  }
  list-style: none;
  padding: 0;
  margin: 0;
  > li {
    position: relative;
    float: left;
    height: 30px;
  }
}
.header_panel {
  background: linear-gradient(
    90deg,
    rgba(185, 172, 228, 0.05) -8.07%,
    rgba(82, 19, 125, 0.05) 107.12%
  );
  padding: 14px 0;
  z-index: 9 !important;
}
.third_level_menu {
  position: absolute;
  top: 0;
  width: 190px;
  list-style: none;
  padding: 0;
  margin: 0;
  display: none;
  margin-left: 60px;
  > li {
    position: relative;
    background: rgba(192, 186, 205, 1);
    margin-right: 0 !important;
    padding: 10px;
    border-bottom: 2px solid white;
    &:hover {
      background: $primary_color;
    }
  }
  a {
    &:hover {
      border: 0 !important;
      color: $white !important;
    }
  }
}
.second_level_menu {
  position: absolute;
  top: 30px;
  left: -15px;
  text-align: center;
  list-style: none;
  padding: 0;
  margin: 0;
  display: none;
  width: 180px;
  padding-top: 18px;
  > li {
    position: relative;
    background: rgba(192, 186, 205, 1);
    margin-right: 0 !important;
    padding: 10px;
    border-bottom: 2px solid white;
    &:hover {
      background: $primary_color;
    }
  }
  a {
    color: $white;
    &:hover {
      border: 0 !important;
      color: $white !important;
    }
  }
}
.dropdown_item {
  svg {
    transition: 0.5s;
    width: 20px;
    height: 20px;
  }
  &:hover {
    svg {
      transform: rotate(180deg);
      transition: 0.5s;
      color: $primary_color;
    }
    .dropdown_parent {
      color: $primary_color;
      border-bottom: 2px solid $primary_color !important;
    }
  }
}
ul.second_level_menu {
  .fa-angle-right {
    position: absolute;
    right: 0;
    padding: 4px 10px;
  }
}
.header_right_side_button {
  display: flex !important;
  justify-content: flex-end !important;
}
.login_btn {
  a {
    border: 1px solid $primary_color;
    margin-left: 10px;
    padding: 12px 24px;
    text-decoration: none;
    font-weight: 600;
    font-size: 16px;
    color: $primary_color !important;
  }
}
.see_doctor {
  a {
    border: 1px solid $primary_color;
    margin-left: 10px;
    padding: 12px 20px;
    background-color: $primary_color;
    color: $white !important;
    text-decoration: none;
    font-weight: 600;
    font-size: 16px;
  }
}
.menu_btn_wrap{
  display: none;
}
.head_left_box{
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.icon_button {
  padding: 0;
  background-color: transparent;
  svg{
    color: $primary_color !important;
      font-size: 44px;
  }
  &:hover {
      border: 0;
  }
  &:active {
      outline: none;
      border: 0;
  }
  &:enabled {
      outline: none;
      border: 0;
  }
}


/* Responsive  */

/*Mobile*/
@media (max-width:767px) {
    
  /*.hide_mobile_ipad{display: none}
  .hide_for_mobile{display: none}   
  .hide_desktop{display: block} */ 
  .global_container {padding: 0 15px;}    
  .header_center{
    display: none;
  }
  .header_right {
    display: none;
  }
  .header_left{
    width: 100%;
  }
  .menu_btn_wrap{
    margin-right: 30px;
    display: block;
  }
  /*****Mobile Header*****/
  
  .mobile_header_panel{ padding: 10px 0;}
  /*.mobile_header_data_wrap{display: flex; justify-content: space-between;align-items: center;}*/
  .mobile_menu{display: flex; align-items: center;     justify-content: space-between;}
  .menu_icon_wrap{}
  .menu_icon_wrap img{}
  .mobile_logo_wrap{}
  .mobile_logo_wrap img{width: 120px;}
  .mobile_header_button{display: flex; justify-content: flex-end;align-items: center;}
  .m_login_btn{}
  .m_login_btn a{}
  .see_a_doctor{}
  .see_a_doctor a{}    
  
   
  .wrap_mobile_ipad_menu {background: linear-gradient(167.95deg, rgba(192, 186, 205, 0.1) 0%, rgba(82, 19, 125, 0.1) 100%),
  linear-gradient(0deg, #FFFFFF, #FFFFFF);
  ;position: fixed;right: 0;top: 0;bottom: 0;padding: 0px;
  left: 0;width: 100%;transition: 0.5s;transform: scale(0);-ms-transform: (0);  -webkit-transform: (0);}     
  .show_menu {left: 0;transform: scale(1);transition: 0.5s;-ms-transform: (0.5s); -webkit-transform: (0.5s);} 
  .nav-dropdown {display: none;z-index: 1;box-shadow: 0 3px 12px rgba(0, 0, 0, 0.15);}
  .mobile_all_slide_item{display: -webkit-box;display: -ms-flexbox;display: flex;min-height: 85vh;
  -webkit-box-orient: vertical;-webkit-box-direction: normal;-ms-flex-direction: column;flex-direction: column;}   
  .mobile_menu_item{  display: -webkit-box;display: -ms-flexbox;display: flex;-webkit-box-flex: 1;-ms-flex: 1;flex: 1;float: none;-webkit-box-orient: vertical;-webkit-box-direction: normal; -ms-flex-direction: column; flex-direction: column;-webkit-box-pack: center;-ms-flex-pack: center;justify-content: center;margin: 0 auto;  }   
  .wrap_m_btn {display: flex!important;justify-content: center!important;}
  .m_login_btn a{border: 1px solid $primary_color;margin: 5px;padding: 10px 20px;background-color: $primary_color;color: white;text-decoration: none;font-weight: 600;font-size: 16px; border-radius: 0px;}
  .see_a_doctor{}
  .see_a_doctor a{border: 1px solid $primary_color;margin: 5px;padding: 10px 10px;text-decoration: none;font-weight: 600;
  font-size: 16px;color: $primary_color; border-radius: 0px;}  
  .wrap_m_btn .m_login_btn,
  .wrap_m_btn .see_a_doctor{ width: 50%;}
  .wrap_m_btn .m_login_btn a,
  .wrap_m_btn .see_a_doctor a{display: inherit;text-align: center;}
  .close_btn_cl {margin-bottom: 8px;text-align: right;padding: 10px;}
  .close_btn_cl i {font-size: 25px;} 
      
      
      
  #wrap_mobile_menu {width: 250px;}
  #wrap_mobile_menu li {list-style-type: none;}
  #wrap_mobile_menu ul li a{ color: black;text-decoration: none;font-size: 20px;display: block;padding: 10px 15px;transition: all 0.15s;position: relative;border-radius: 0;text-align: center;font-weight: 500;}
  #wrap_mobile_menu>ul.show-dropdown>li.active>a,
  #wrap_mobile_menu>ul>li>ul.show-dropdown>li.active>a,
  #wrap_mobile_menu>ul>li>ul>li>ul.show-dropdown>li.active>a,
  #wrap_mobile_menu>ul>li>ul>li>ul>li>ul.show-dropdown>li.active>a,
  #wrap_mobile_menu>ul>li>ul>li>ul>li>ul>li>ul.show-dropdown>li.active>a{color: $primary_color !important;}
  #wrap_mobile_menu>ul>li>ul,
  #wrap_mobile_menu>ul>li>ul>li>ul,
  #wrap_mobile_menu>ul>li>ul>li>ul>li>ul,
  #wrap_mobile_menu>ul>li>ul>li>ul>li>ul>li>ul {display: none;}
  #wrap_mobile_menu>ul>li.active>ul.show-dropdown,
  #wrap_mobile_menu>ul>li>ul>li.active>ul.show-dropdown,
  #wrap_mobile_menu>ul>li>ul>li>ul>li.active>ul.show-dropdown,
  #wrap_mobile_menu>ul>li>ul>li>ul>li>ul>li.active>ul.show-dropdown {display: block;}
  #wrap_mobile_menu>ul>li>ul,
  #wrap_mobile_menu>ul>li>ul>li>ul,
  #wrap_mobile_menu>ul>li>ul>li>ul>li>ul,
  #wrap_mobile_menu>ul>li>ul>li>ul>li>ul>li>ul {}
  #wrap_mobile_menu a:not(:only-child):after {content: "\f0d7";position: absolute;right: 20px;top: 14px;
  font-size: 15px;font-family: "Font Awesome 5 Free";display: inline-block;padding-right: 3px;vertical-align: middle;
  font-weight: 900;transition: 0.5s;}
  #wrap_mobile_menu .active>a:not(:only-child):after {transform: rotate(180deg);}
  .drp_dwn_tri {padding: 0;}  
  .second_lavel_dropdown {background-color: #C0BACD;padding: 0 !important;} 
  .second_lavel_dropdown li{    position: relative;background: rgba(192, 186, 205, 1);margin-right: 0 !important;
  border-bottom: 2px solid white;} 
  .second_lavel_dropdown li:last-child{border: 0 !important}
  .second_lavel_dropdown li a{padding: 0 !important;  color: white !important;}
  .second_lavel_dropdown a:not(:only-child):after{    top: 6px !important;}
  .second_lavel_dropdown li {padding: 10px 0;}
  .third_trigger_btn{padding: 10px 0 !important;}
  .third_lavel_dropdown{}
  /*.third_lavel_dropdown li:last-child{padding-bottom: 0;}    */ 
  .active .trigger_first{}
  .wrap_bottom_data {text-align: center;border-top: 1px solid #c3bebe;padding-top: 20px;margin: 0 25px;}
  .wrap_bottom_data a{color: $primary_color;text-decoration: none;font-size: 18px;font-weight: 500}    
  .m_menu_login_btn {border-bottom: 2px solid $primary_color;margin: 0 20px;padding-bottom: 20px;}
    
  .footer_top_menu_wrap {display: inherit;} 
  .footer_top_first { width: 100%;}    
  .wrap_logo_social {display: inherit;}    
  .wrap_socail_data {justify-content: flex-start !important;}    
  .wrap_socail_data a {margin-left: 0;padding-right: 20px;}
  .footer_right_social {padding: 25px 0;}    
  .subscription_sec {display: inherit !important;}
  .subscription_sec form {display: inherit !important;}    
  .subscription_sec input { width: 100%;   } 
  .subscription_sec button { width: 100%;margin: 15px 0 !important;} 
  .footer_top_second h4 { margin-bottom: 20px;} 
  .footer_top_second ul li a { font-size: 15px; }
  .footer_bottom_sec {background-color: $primary_color;padding: 20px 0;}
  .footer_bottom_sec .global_container {padding: 0;}   
   .wrap_logo_social {padding: 0 15px;}
  .footer_copywrite {padding: 0 15px;}    
  .footer_copywrite p {margin: 0;text-align: left;padding-top: 20px;}  
      
  .header_logo img{
    height: 29px;
  }  
  .icon_button svg{
    height: 30px;
  }
  }
  
  /*small mobile devices*/
  @media (min-width:320px) and (max-width:480px) {
   
   
  }
  
  /*landscape mobiles devices*/
  @media (max-width:736px) and (orientation:landscape) {}
  
  
  
  /*tablet devices (both orentations)*/
  @media (min-width:768px) and (max-width:1024px) {
    .header_center{
      display: none;
    }
    .header_right {
      width: 50%;
    }
    .menu_btn_wrap{
      margin-right: 30px;
      display: block;
    }
  /*.hide_for_ipad{display: none}    
  .hide_mobile_ipad{display: none}*/
  .hide_desktop{display: block}  
  .global_container {padding: 0 25px;}    
     
  /*****Mobile Header*****/
  
  .mobile_header_panel{ padding: 20px 0;}
  /*.mobile_header_data_wrap{display: flex; justify-content: space-between;align-items: center;}*/
  .mobile_menu{display: flex; align-items: center;     justify-content: space-between;}
  .menu_icon_wrap{}
  .menu_icon_wrap img{}
  .mobile_logo_wrap{}
  .mobile_logo_wrap img{width: 120px;}
  .mobile_header_button{display: flex; justify-content: flex-end;align-items: center;}
  .m_login_btn{}
  .m_login_btn a{border: 1px solid $primary_color;margin-left: 10px;padding: 10px 20px;background-color: $primary_color;color: white;text-decoration: none;font-weight: 600;font-size: 16px; border-radius: 6px;}
  .see_a_doctor{}
  .see_a_doctor a{border: 1px solid $primary_color;margin-left: 10px;padding: 10px 24px;text-decoration: none;font-weight: 600;font-size: 16px;color: $primary_color; border-radius: 6px;}  
  .mobile_menu {justify-content: flex-start!important;}   
  .mobile_header_data_wrap {display: flex; justify-content: space-between!important;align-items: center;}
  .logo_for_ipad{margin-left: 30px;}
  .logo_for_ipad img{width: 140px;}
  .wrap_mobile_ipad_menu {background: linear-gradient(167.95deg, rgba(192, 186, 205, 0.1) 0%, rgba(82, 19, 125, 0.1) 100%),
  linear-gradient(0deg, #FFFFFF, #FFFFFF);
  ;position: fixed;right: 0;top: 0;bottom: 0;padding: 0px;left: -100%;width: 50%;transition: 0.5s;  }    
  .show_menu {left: 0;}     
  .nav-dropdown {display: none;z-index: 1;box-shadow: 0 3px 12px rgba(0, 0, 0, 0.15);}
      
   
      
   #wrap_mobile_menu {width: 250px;}
  #wrap_mobile_menu li {list-style-type: none;}
  #wrap_mobile_menu ul li a{ color: black;text-decoration: none;font-size: 24px;display: block;padding: 20px 15px;transition: all 0.15s;position: relative;border-radius: 0;text-align: center;font-weight: 500;}
  #wrap_mobile_menu>ul.show-dropdown>li.active>a,
  #wrap_mobile_menu>ul>li>ul.show-dropdown>li.active>a,
  #wrap_mobile_menu>ul>li>ul>li>ul.show-dropdown>li.active>a,
  #wrap_mobile_menu>ul>li>ul>li>ul>li>ul.show-dropdown>li.active>a,
  #wrap_mobile_menu>ul>li>ul>li>ul>li>ul>li>ul.show-dropdown>li.active>a{color: $primary_color !important;     border-bottom: 1px solid $primary_color;}
  #wrap_mobile_menu>ul>li>ul,
  #wrap_mobile_menu>ul>li>ul>li>ul,
  #wrap_mobile_menu>ul>li>ul>li>ul>li>ul,
  #wrap_mobile_menu>ul>li>ul>li>ul>li>ul>li>ul {display: none;}
  #wrap_mobile_menu>ul>li.active>ul.show-dropdown,
  #wrap_mobile_menu>ul>li>ul>li.active>ul.show-dropdown,
  #wrap_mobile_menu>ul>li>ul>li>ul>li.active>ul.show-dropdown,
  #wrap_mobile_menu>ul>li>ul>li>ul>li>ul>li.active>ul.show-dropdown {display: block;}
  #wrap_mobile_menu>ul>li>ul,
  #wrap_mobile_menu>ul>li>ul>li>ul,
  #wrap_mobile_menu>ul>li>ul>li>ul>li>ul,
  #wrap_mobile_menu>ul>li>ul>li>ul>li>ul>li>ul {}
  #wrap_mobile_menu a:not(:only-child):after {content: "\f0d7";position: absolute;right: 5px;
  top: 27px;font-size: 15px;font-family: "Font Awesome 5 Free";display: inline-block;padding-right: 3px;vertical-align: middle;
  font-weight: 900;transition: 0.5s;}
  #wrap_mobile_menu .active>a:not(:only-child):after {transform: rotate(180deg);}
  .drp_dwn_tri {padding: 0;}  
  .second_lavel_dropdown {padding: 0 !important;} 
  .second_lavel_dropdown li{position: relative;margin-right: 0 !important;border-bottom: 2px solid #C0BACD;;} 
  .second_lavel_dropdown li:last-child{border: 0 !important}
  .second_lavel_dropdown li a{padding: 5px 0 !important;  color: #383838 !important;}
  .second_lavel_dropdown a:not(:only-child):after{    top: 11px !important;right: 40px !important;}
  .second_lavel_dropdown li {padding: 10px 0;}
  .third_trigger_btn{padding: 10px 0 !important;}
  .third_lavel_dropdown{}
  /*.third_lavel_dropdown li:last-child{padding-bottom: 0;}    */ 
  .active .trigger_first{}
  .wrap_bottom_data {text-align: center;border-top: 1px solid #c3bebe;padding-top: 20px;margin: 0 25px;}
  .wrap_bottom_data a{color: $primary_color;text-decoration: none;font-size: 18px;font-weight: 500}    
  .m_menu_login_btn {border-bottom: 2px solid $primary_color;margin: 0 20px;padding-bottom: 20px;}   
  .mobile_all_slide_item {display: -webkit-box;display: -ms-flexbox;display: flex;
  min-height: 95vh; -webkit-box-orient: vertical; -webkit-box-direction: normal;-ms-flex-direction: column;flex-direction: column;}
      
  .mobile_menu_item { display: -webkit-box; display: -ms-flexbox; display: flex; -webkit-box-flex: 1; -ms-flex: 1;
   flex: 1; float: none; -webkit-box-orient: vertical; -webkit-box-direction: normal; -ms-flex-direction: column;
   flex-direction: column; -webkit-box-pack: center; -ms-flex-pack: center; justify-content: center; margin: 0 auto;}       
  .m_menu_login_btn {display: none;}   
  .close_btn_cl {position: absolute;right: 0;padding: 14px;}    
  .close_btn_cl i {font-size: 30px;}    
   
      
      
  .wrap_logo_social {display: inherit;}    
  .wrap_socail_data {justify-content: flex-start !important;}    
  .wrap_socail_data a {margin-left: 0;padding-right: 20px;}
  .footer_right_social {padding: 25px 0;}    
  .footer_top_second h4 {margin-bottom: 20px;} 
  .footer_top_second ul li a {font-size: 15px; }
  .footer_bottom_sec {background-color: $primary_color;padding: 20px 0;}
  .footer_bottom_sec .global_container { padding: 0;}    
  .wrap_logo_social { padding: 0 15px;} 
  .footer_copywrite {padding: 0 15px;}    
  .footer_copywrite p { margin: 0; text-align: left; padding-top: 20px;}   
  .footer_top_menu_wrap { display: inherit;}   
  .footer_top_first {width: 100%;}   
  .footer_top_second {width: 32%;display: inline-grid;}   
  .subscription_sec {margin-bottom: 30px;} 
  .subscription_sec input { width: 340px;}     
  .wrap_mobile_ipad_menu { z-index: 9999;}   
      
      
  }
  /*For small screens and laptops devices*/
@media (min-width:980px) and (max-width:1199px) {
  .header_center{
    width: 57%;
  }
  .header_right {
    width: 28%;
  }
  .header_left{
    width: 18%;
  }
  .sign_up_wrapper {
    padding: 25px 40px;
  }
}
</style>
