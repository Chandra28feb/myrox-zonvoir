import { createRouter, createWebHistory } from "vue-router";
import { useAuthStore } from "@/js/store/authentication";
import { authToken, checkAuth } from "../utils/common";
import { getToken } from "../services/Jwt";
// check if user not login then Dashboard related page not show

// function adminGuard(to, from, next) {
//     authToken();
//     const { isUser, isEmailVerified, isPhoneVerified, hasToken } = checkAuth();
//     console.log(isUser, isEmailVerified, isPhoneVerified, hasToken, "vis");
//     if (hasToken && isEmailVerified && isPhoneVerified) {
//         next({ name: "dashboard" });
//     } else {
//         next({ name: "register" });
//     }
// }
// function sharedGuard(to, from, next) {
//     authToken();
//     const { isUser, isEmailVerified, isPhoneVerified, hasToken } = checkAuth();
//     if (hasToken && !isPhoneVerified) {
//         next({ name: "phone-otp" });
//     } else if (hasToken && !isEmailVerified) {
//         next({ name: "email-otp" });
//     }
//     {
//         next({ name: "register" });
//     }
// }
const routes = [
    {
        path: "/",
        redirect: "/register",
        component: () => import("../layout/AuthLayout.vue"),
        children: [
            {
                path: "/login",
                name: "login",
                component: () => import("../views/authentication/SignIn.vue"),
                meta: {
                    pageTitle: "Login",
                    unAuthorized: true,
                },
            },
            {
                path: "/register",
                name: "register",
                component: () => import("../views/authentication/SignUp.vue"),
                meta: {
                    pageTitle: "Register",
                    unAuthorized: true,
                },
            },
            {
                path: "/account-created",
                name: "account-created",

                component: () =>
                    import("../views/authentication/AccountCreated.vue"),
                meta: {
                    pageTitle: "Account Created",
                },
            },
            {
                path: "/verify-email",
                name: "verify-email",
                component: () =>
                    import("../views/authentication/VerifyEmail.vue"),
                meta: {
                    pageTitle: "Verify Email",
                },
            },
            {
                path: "/phone-otp",
                name: "phone-otp",
                component: () => import("../views/authentication/PhoneOTP.vue"),
                meta: {
                    pageTitle: "Phone OTP",
                    authRequired: true,
                    isPhone: true,
                },
            },
            {
                path: "/email-otp",
                name: "email-otp",
                component: () => import("../views/authentication/EmailOTP.vue"),
                meta: {
                    pageTitle: "Email OTP",
                    authRequired: true,
                    isEmail: true,
                },
            },
            {
                path: "/identity-verification",
                name: "identity-verification",
                component: () =>
                    import("../views/authentication/IdentityVerification.vue"),
                meta: {
                    pageTitle: "Identity-Verification",
                    authRequired: true,
                },
            },
            {
                path: "/password-updated",
                name: "password-updated",
                component: () =>
                    import("../views/authentication/NewPasswordUpdated.vue"),
                meta: {
                    pageTitle: "Password Updated",
                },
            },
            {
                path: "/forgot-password",
                name: "forgot-password",
                component: () =>
                    import("../views/authentication/ForgotPassword.vue"),
                meta: {
                    pageTitle: "Forgot Password",
                },
            },
            {
                path: "/reset-password",
                name: "reset-password",
                component: () =>
                    import("../views/authentication/ResetPassword.vue"),
                meta: {
                    pageTitle: "Reset password",
                },
            },
            {
                // the 404 route, when none of the above matches
                path: "/404",
                name: "404",
                component: () => import("../views/authentication/Error404.vue"),
                meta: {
                    pageTitle: "Error 404",
                },
            },
            {
                path: "/500",
                name: "500",
                component: () => import("../views/authentication/Error500.vue"),
                meta: {
                    pageTitle: "Error 500",
                },
            },
        ],
    },
    {
        path: "/dash",
        redirect: "/dashboard",
        component: () => import("../layout/DashboardLayout.vue"),
        meta: {
            authRequired: true,
        },
        children: [
            {
                path: "/dashboard",
                name: "dashboard",
                component: () => import("../layout/Dashboard.vue"),
                meta: {
                    pageTitle: "Dashboard",
                    authRequired: true,
                },
            },
            {
                path: "/patient",
                name: "patient",
                component: () => import("../layout/Patient.vue"),
                meta: {
                    pageTitle: "Patient",
                    authRequired: true,
                },
            },
        ],
    },
    // {
    //     path: "/dashboard",
    //     name: "dashboard",
    //     component: () => import("../layout/Dashboard.vue"),
    //     meta: {
    //         pageTitle: "Dashboard",
    //     },
    // },
    // {
    //     path: "/patient",
    //     name: "patient",
    //     component: () => import("../layout/Patient.vue"),
    //     meta: {
    //         pageTitle: "Patient",
    //     },
    // },
    {
        path: "/:pathMatch(.*)*",
        redirect: "/404",
    },
];

const router = createRouter({
    history: createWebHistory(),
    routes,
});

router.beforeResolve(() => {
    authToken();
});

router.afterEach(() => {
    authToken();
});

router.beforeEach((to, from, next) => {
    const isAuthenticated = authToken() ? true : false;
    const isLoggedIn = JSON.parse(getToken());
    document.title = `${to.meta.pageTitle}`;

    if (to.meta.authRequired && !isAuthenticated) {
        next({ name: "login" });
    } else {
        next();
    }

    // Scroll page to top on every route change
    window.scrollTo({
        top: 0,
        left: 0,
        behavior: "smooth",
    });
});

export default router;
