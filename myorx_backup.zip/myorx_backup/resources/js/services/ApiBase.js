import http from "./http";

class ApiBase {
    getAll(resource) {
        return http.get(`${resource}`);
    }

    get(resource, params) {
        return http.get(`${resource}/${params}`);
    }

    create(resource, params) {
        return http.post(`${resource}`, params);
    }
    postWithParams(resource, params, data) {
        return http.post(`${resource}/${params}`, data);
    }

    update(resource, params) {
        return http.put(`${resource}`, params);
    }

    delete(resource, params) {
        return http.delete(`${resource}`, params);
    }

    deleteAll(resource) {
        return http.delete(`${resource}`);
    }

    //   findByTitle(resource, params) {
    //     return http.get(`/tutorials?title=${title}`);
    //     return http.get(`/tutorials?title=${title}`);
    //   }
}

export default new ApiBase();
