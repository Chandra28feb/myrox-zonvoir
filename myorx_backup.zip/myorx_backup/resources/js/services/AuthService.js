
// login

export const login = () => {
    return window.localStorage.getItem('id_token');
  };
  // signup
  
  export const signup = (token) => {
    window.localStorage.setItem('id_token', token);
  };
  
  

  
  export default { getToken, saveToken, destroyToken };