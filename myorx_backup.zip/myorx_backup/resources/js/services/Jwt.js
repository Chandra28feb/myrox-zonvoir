// get token form localStorage

export const getToken = () => {
    // return window.localStorage.getItem("uid_token");
    return window.localStorage.getItem("a6b8dea9756f");
};
// save token into localStorage
export const saveToken = (token) => {
    window.localStorage.setItem("a6b8dea9756f", token);
};

// remove token form sessionStorage
export const destroyToken = () => {
    window.localStorage.removeItem("a6b8dea9756f");
};
// remove token form localStorage
export const destroySessionToken = () => {
    window.sessionStorage.removeItem("3de333b4d050");
};
export const getSessionToken = () => {
    return window.sessionStorage.getItem("3de333b4d050");
};
// save token into sessionStorage
export const saveSessionToken = (data) => {
    window.sessionStorage.setItem("3de333b4d050", data);
};

export default {
    getToken,
    saveToken,
    destroyToken,
    saveSessionToken,
    destroySessionToken,
    getSessionToken,
};
