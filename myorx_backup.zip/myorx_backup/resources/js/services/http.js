import axios from "axios";
import { authToken } from "../utils/common";
import Jwt from "./Jwt";

export default axios.create({
    baseURL: import.meta.env.VITE_API_URL,
    // baseURL: "http://localhost:8000/api/",
    headers: {
        // Authorization: `Bearer ${Jwt.getToken()}`,
        Authorization: `Bearer ${authToken()}`,
        "Content-type": "application/json",
    },
});
