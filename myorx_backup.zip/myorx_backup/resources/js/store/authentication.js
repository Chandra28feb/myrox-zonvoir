import { ref } from "vue";
import ApiBase from "../services/ApiBase";
import Jwt from "../services/Jwt";
import { defineStore } from "pinia";
import { authToken } from "../utils/common";
export const useAuthStore = defineStore("auth", () => {
    const isAuthenticated = ref(authToken());
    function purgeAuth() {
        isAuthenticated.value = false;
        PassportService.destroyToken();
    }
    function setAuth() {
        isAuthenticated.value = true;
        Jwt.saveToken(token);
    }
    function verifyAuth() {
        if (Jwt.getToken()) {
            ApiBase.create("verify_token", { api_token: Jwt.getToken() })
                .then(({ data }) => {
                    setAuth(data);
                })
                .catch(({ response }) => {
                    purgeAuth();
                });
        } else {
            purgeAuth();
        }
    }
    return {
        isAuthenticated,
        verifyAuth,
    };
});
