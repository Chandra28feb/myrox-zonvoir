export const getAssetPath = (path) => {
    const url = `../../assets/${path}`;
    console.log(import.meta.env.APP_URL, typeof url);
    return url;
};
