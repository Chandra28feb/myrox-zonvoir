// import { toast } from "vue3-toastify";
import router from "@/js/router/index";
export const errorHandler = (res) => {
    if (res.status === 500) {
        router.push({ name: "500" });
    } else if (res.status === 404) {
        router.push({ name: "404" });
    } else if (res && typeof res.error === "string") {
        return res.error;
    } else if (typeof res.message === "string") {
        return res.message;
    } else if (typeof res.data.message === "string") {
        return res.data.message;
    } else if (typeof res.data.error === "string") {
        return res.data.error;
    } else if (res.status === 500) {
        router.push({ name: "500" });
    } else if (res.status === 404) {
        router.push({ name: "404" });
    }
};
