import { getToken } from "@/js/services/Jwt";
import router from "@/js/router/index";
export const removeSpace = (obj) => {
    for (let key in obj) {
        if (typeof obj[key] === "string") {
            obj[key] = obj[key].replace(/\s+/g, "");
        }
    }
    return obj;
};

export const isObjectEmpty = (objectName) => {
    return (
        objectName &&
        objectName == null &&
        Object.keys(objectName).length === 0 &&
        objectName.constructor === Object
    );
};

export const checkAuth = () => {
    const token = JSON.parse(getToken());
    let hasToken;
    let isUser;
    let userRole;
    let isPhoneVerified = false;
    let isEmailVerified = false;
    if (isObjectEmpty(token) || isObjectEmpty(token) === null) {
        // router.push({ name: "register" });
    } else {
        hasToken =
            token.hasOwnProperty("ta3e1dfhdih236cau") &&
            token.ta3e1dfhdih236cau;
        isUser = "u56b4dd0b404d09e1" in token && token.u56b4dd0b404d09e1;
        isPhoneVerified =
            "m82fe136sd33333ca" in token && token.m82fe136sd33333ca;
        isEmailVerified =
            "e25e13612237df24k" in token && token.e25e13612237df24k;
        userRole = "ur3da23ed4lbdd0be" in token && token.ur3da23ed4lbdd0be;
    }
    return { hasToken, isPhoneVerified, isEmailVerified, isUser, userRole };
};

export const authToken = () => {
    const token = JSON.parse(getToken());
    let authTokenValue;
    if (isObjectEmpty(token) || isObjectEmpty(token) === null) {
        return;
    } else {
        authTokenValue =
            token.hasOwnProperty("ta3e1dfhdih236cau") &&
            token.ta3e1dfhdih236cau;
    }
    return authTokenValue;
};
