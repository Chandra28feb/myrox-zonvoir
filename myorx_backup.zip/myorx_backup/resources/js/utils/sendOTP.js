import router from "@/js/router/index";
import ApiBase from "@/js/services/ApiBase";
import { destroyToken, saveSessionToken } from "../services/Jwt";
import { toast } from "vue3-toastify";
import { errorHandler } from "./ErrorHandler";
export const sendPhoneOTP = async () => {
    let loadingRes;
    let message;
    await ApiBase.getAll("send-otp")
        .then(({ data }) => {
            if (data) {
                console.log("res", data);
                router.push({ name: "phone-otp" });
            }
        })
        .catch(({ response }) => {
            if (response) {
                message = errorHandler(response);
            }
            loadingRes = false;
            return { message, loadingRes };
        })
        .finally(() => {
            loadingRes = false;
            return { message, loadingRes };
        });
    return { message, loadingRes };
};
export const sendEmailOTP = () => {
    let loadingRes;
    let message;
    ApiBase.getAll("send-verification-email")
        .then(({ data }) => {
            if (data) {
                console.log("res kk", data);
                router.push({ name: "email-otp" });
            }
        })
        .catch(({ response }) => {
            if (response) {
                console.log("err", response);
                message = errorHandler(response);
            }
            loadingRes = false;
            return { message, loadingRes };
        })
        .finally(() => {
            loadingRes = false;
            return { message, loadingRes };
        });
    return { message, loadingRes };
};

export const sendRecoveryEmail = async (userData) => {
    let loadingRes;
    let message;
    await ApiBase.create("forgot-password", userData)
        .then(({ data }) => {
            if (data) {
                console.log("res", data);
                toast(data.success, {
                    type: "success",
                });
                let sessData = JSON.stringify({
                    s4874bc701a33: userData.email,
                });
                saveSessionToken(sessData);
                router.push({ name: "verify-email" });
            }
        })
        .catch(({ response }) => {
            if (response) {
                message = errorHandler(response);
            }
            loadingRes = false;
            return { message, loadingRes };
        })
        .finally(() => {
            loadingRes = false;
            return { message, loadingRes };
        });
    return { message, loadingRes };
};
// on logout
export const logoutUser = () => {
    let loadingRes;
    let message;
    ApiBase.getAll("logout")
        .then(({ data }) => {
            if (data) {
                console.log("sdfhsdjk", data);
                destroyToken();
                router.push({ name: "login" });
                toast("Logout successfully", {
                    type: "success",
                });
            }
        })
        .catch(({ response }) => {
            if (response) {
                console.log("error", response);
                // message = errorHandler(response);
            }
            loadingRes = false;
            return { message, loadingRes };
        })
        .finally(() => {
            loadingRes = false;
            return { message, loadingRes };
        });
    return { message, loadingRes };
};
export default { sendPhoneOTP, sendEmailOTP, sendRecoveryEmail, logoutUser };
