import { ref } from "@vue/reactivity";

export default function useValue(value) {
    let value = ref(value);
    return { va };
}
