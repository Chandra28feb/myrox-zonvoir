<template>
  <!--begin::Wrapper-->
  <!-- welcome_msg -->

  <AuthSide :side-full-img="welcome_msg" />
  <div class="righ_section_auth_wrapper order-2">
    <div class="sign_up_wrapper">
      <AuthTitle title="Welcome to myoRX" subTitle="Your account was successfully created." description="Please verify your phone number & email address on next screens." />
      <div v-if="serverMessage">
        <AlertBox :message="serverMessage"/>
      </div>
        <!--begin::Actions-->
        <div class="row mb-4">
          <div class="col-xl-12">
            <div class="text-center mb-1">

              <button
              ref="submitButton"
              type="submit"
              class="btn btn-lg btn-primary btn_cus_primary customize_btn w-100"
              @click="goVerifyPhoneOTP()"
              >
              <span class="indicator-label"> Continue </span>
              <span class="indicator-progress">
                Please wait...
                <span
                  class="spinner-border spinner-border-sm align-middle ms-2"
                ></span>
              </span>
            </button>
            </div>
          </div>
        </div>

        <!--begin::Input group-->
        <div class="privacy_policy row">
          <div class="col-xl-12 mb-2">
            <BaseLink page-link="/" link-title="Back To myoRX" :imgIcon="HomeIcon" />
          </div>
        </div>
        <!--end::Input group-->

        <!--end::Actions-->
      </div>
  </div>
  <!-- end:: wrapper-->
</template>
<script setup>
import AuthTitle from "./components/AuthTitle.vue"
import AuthSide from "./components/AuthSide.vue";
import HomeIcon from "@/assets/icons/home_outline.svg"
import BaseLink from "@/js/components/links/BaseLink.vue";
import welcome_msg from "@/assets/custom/welcome_msg.svg"
import { useRouter } from "vue-router";
import {getToken} from '@/js/services/Jwt'
import ApiBase from "@/js/services/ApiBase";
import { sendPhoneOTP } from"@/js/utils/sendOTP"
import { errorHandler } from "@/js/utils/ErrorHandler"
import { authToken, checkAuth } from "@/js/utils/common";
import {ref } from "vue";
import AlertBox from "@/js/components/AlertBox.vue";
    const router = useRouter();
    let serverMessage= ref(null);
    let loading = $ref(false);
    const submitButton = ref(null);
    // const { isUser } = checkAuth();
    // isUser ? '':router.push({name:'register'});

    const goVerifyPhoneOTP =  async () => {
      if (submitButton.value) {
        submitButton.value.disabled = true;
        submitButton.value.setAttribute("data-kk-indicator", "on");
      }
      loading=true;
      // ResendLoading.value=true;
      const {message, loadingRes } = await sendPhoneOTP();
      console.log('resdata',message, loadingRes);
      if(!loadingRes){
    submitButton.value.disabled = false;
    submitButton.value.removeAttribute("data-kk-indicator", "on");
    }
        message ? serverMessage.value = message :''

    };

</script>
