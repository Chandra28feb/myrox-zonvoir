<template>
  <AuthSide :side-full-img="err500" />
  <div class="righ_section_auth_wrapper order-2">
    <div class="sign_up_wrapper">
      <div class="form_title">
        <h4 class="error_code">500 !</h4>
        <h4 class="error_message">Server Error..</h4>
        <h6
          class="link-primary fw-bold mb-1 other_link fs-6"
        >
          Page not found?
          <router-link to="/" class="text-primary-400 text-decoration-none fs-4 fw-normal">
            Go back Home!
          </router-link>
        </h6>
      </div>
      <div class="symbol_wrapper">
        <img
          :src="serverErr"
          alt="server"
          class="img-responsive"
        />
      </div>
      <div class="">
        <BaseLink page-link="/" link-title="Back To myoRX" :imgIcon="HomeIcon" />
      </div>
    </div>
  </div>
</template>

<script setup>
import serverErr from "@/assets/custom/server_err.svg"
import HomeIcon from "@/assets/icons/home_outline.svg"
import BaseLink from "@/js/components/links/BaseLink.vue";
import err500 from "@/assets/custom/error500.svg"
import AuthSide from "./components/AuthSide.vue";
</script>
