<template>
  <!--begin::Wrapper-->
  <!-- forgot_password.svg -->
  <AuthSide :side-full-img="forgot_password" />
  <div class="righ_section_auth_wrapper order-2">
    <div class="sign_up_wrapper">
      <AuthTitle title="Forgot your Password?" description="It happens all of us. Let’s help you out." />
        <!-- or section end -->
        <div class="_form_wraper">
          <ForgotPasswordForm />
        </div>
      </div>
  </div>
  <!--end::Wrapper-->
</template>

<script setup>
import AuthTitle from "./components/AuthTitle.vue"
import AuthSide from "./components/AuthSide.vue";
import ForgotPasswordForm from "./components/ForgotPasswordForm.vue";
import forgot_password from "@/assets/custom/forgot_password.svg"
import { onMounted } from "vue";
import { destroyToken } from "@/js/services/Jwt";
onMounted(()=>{
  destroyToken();
})
</script>
