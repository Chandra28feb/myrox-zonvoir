<template>
  <!--begin::Wrapper-->
  <!-- email_otp.svg -->
  <AuthSide :side-full-img="identityImg" />
  <div class="righ_section_auth_wrapper order-2">
    <div class="sign_up_wrapper">
      <AuthTitle title="Identity Verification" description="Help us confirm your identity." />
        <div class="doc_upload_wraper">
          
          <div class="doc_type">
            <img
              :src="document"
              alt="file"
              class="img-responsive"
            />
          </div>
          <div class="doc_other_detail">
            <h6>GOVERNMENT ISSUED PHOTO ID</h6>
            <div class="d-flex align-items-center action_btns">
              <button class="btn btn-primary mr-2">Capture</button>
              <button class="btn btn-primary mr-2">Upload</button>
            </div>
            <p>Gov ID should be in(.jpg, .jpeg, .png format only)</p>
          </div>
        </div>
        <div class="doc_upload_wraper">
          <div class="doc_type">
            <img
            :src="document"
              alt="file"
              class="img-responsive"
            />
          </div>
          <div class="doc_other_detail">
            <h6>selfie</h6>
            <div class="d-flex align-items-center py-3">
              <button class="btn btn-primary mr-2">Capture</button>
            </div>
          </div>
        </div>
  
        <!--begin::Actions-->
        <div class="row ">
          <div class="col-xl-12 mb-4">
            <div class="text-center mb-1">
              <SubmitBtn title="verify"/>
            </div>
          </div>
          <div class="col-xl-12">
            <BaseLink page-link="/" link-title="Back To myoRX" :imgIcon="HomeIcon" />
          </div>
        </div>
        <!--end::Actions-->
    </div>
  </div>

  <!-- end:: wrapper-->
</template>
<script setup>
import AuthSide from "./components/AuthSide.vue";
import AuthTitle from "./components/AuthTitle.vue"
import HomeIcon from "@/assets/icons/home_outline.svg";
import BaseLink from "@/js/components/links/BaseLink.vue";
import SubmitBtn from "@/js/components/buttons/SubmitBtn.vue";
import document from "@/assets/custom/img_place_holder.svg";
import identityImg from '@/assets/custom/identy_verify.svg'
</script>
<style lang="scss">
.action_btns {
  display: flex;
  align-items: center;
  gap: 0 10px;
  padding: 10px 0;
  button {
    width: 49%;
    flex: 1 1 auto;
  }
}
</style>
