<template>
  <!--begin::Wrapper-->

    <!-- new_pass_set.svg -->
    <AuthSide :side-full-img="new_pass_set" />
    <div class="righ_section_auth_wrapper order-2">
      <div class="sign_up_wrapper">
        <AuthTitle title="New Password Configured" description="It happens all of us. Let’s help you out." />
        <div class="symbol_wrapper">
          <img
            :src="success"
            alt="success"
            class="img-responsive"
          />
        </div>
        <div class="greeting_wrapper">
          <h5>Congratulations!</h5>
          <p>Your New Password was Updated Successfully...</p>
        </div>
        <div
          class="other_link "
        >
          <router-link to="/sign-up" class="link-primary fw-700">
            Redirect To your myoRX Profile
          </router-link>
        </div>
      </div>
    </div>
  <!-- end:: wrapper-->
</template>
<script setup>
import AuthTitle from "./components/AuthTitle.vue"
import AuthSide from "./components/AuthSide.vue";
import new_pass_set from "@/assets/custom/new_pass_set.svg"
import success from "@/assets/custom/success.svg"


</script>
