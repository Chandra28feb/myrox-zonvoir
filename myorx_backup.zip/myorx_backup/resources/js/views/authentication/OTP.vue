<template>
  <div style="display: flex; flex-direction: row">
    <v-otp-input
      class="otp_inp_box"
      ref="otpInput"
      input-classes="otp-input"
      separator="-"
      inputType="number"
      :num-inputs="6"
      :should-auto-focus="true"
      :is-input-num="true"
      :conditionalClass="['one', 'two', 'three', 'four']"
      @on-complete="handleOnComplete"
      @on-change="handleOnChange"
    />
  </div>
</template>
<script setup>

import VOtpInput from "vue3-otp-input";

import {  ref } from "vue";
    const emit = defineEmits(['handleOTPData','handleOTPChanged']);
    const otpInput = ref(null)

    const handleOnComplete = (value) => {
      emit('handleOTPData' ,value);
    };
    const handleOnChange = (value) => {
      emit('handleOTPChanged' ,value);
    };

    const clearInput = () => {
      //   otpInput.value.clearInput();
    };
</script>
<style lang="scss">
.otp-input {
  margin: 0 8px;
  font-size: 20px;
  padding: 10px;
  font-weight: 600;
  font-size: 38px;
  line-height: 60px;
  text-align: center;
  letter-spacing: -0.02em;
  color: #52137d;
  width: 64px;
  height: 64px;
  background: #ffffff;
  border: 2px solid #52137d;
  box-shadow: 0px 1px 2px rgba(16, 24, 40, 0.05);
  border-radius: 8px;
  outline: 0;
  &:focus-visible {
    border: 2px solid #52137d;
  }
  &:focus {
    border: 2px solid #52137d;
  }
}
.otp_inp_box {
  line-height: 30px;
  div {
    span {
      font-size: 0;
    }
    &:nth-child(3) {
      span {
        font-size: 3rem;
        font-weight: bold;
        color: #52137d;
        position: relative;
        top: 0px;
      }
    }
  }

  //   &:nth-child(3) {
  //   }
}
/* Background colour of an input field with value */
.otp-input.is-complete {
  background-color: #fff;
}
.otp-input::-webkit-inner-spin-button,
.otp-input::-webkit-outer-spin-button {
  -webkit-appearance: none;
  margin: 0;
}
input::placeholder {
  font-size: 15px;
  text-align: center;
  font-weight: 600;
}
/* Responsive  */

/*Mobile*/
@media (max-width:767px) {
  .otp-input{
  margin: 0 4px;
  font-size: 20px;
  padding: 5px 5px 2px 5px;
  font-weight: 500;
  font-size: 30px;
  line-height: 30px;
  text-align: center;
  letter-spacing: -0.02em;
  color: #52137d;
  width: 44px;
  height: 44px;
  background: #ffffff;
  border: 2px solid #52137d;
  box-shadow: 0px 1px 2px rgba(16, 24, 40, 0.05);
  border-radius: 5px;
  outline: 0;
  }
  .otp_inp_box {
    line-height: 30px;
    div {
      span {
        font-size: 0;
      }
      &:nth-child(3) {
        span {
          font-size: 1rem;
          top: 0px;
        }
      }
    }
  
    //   &:nth-child(3) {
    //   }
  }
}
</style>
