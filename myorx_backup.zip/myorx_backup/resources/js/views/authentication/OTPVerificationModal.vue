<template>
  <div class="success_full_verification">
    <div class="success_mark">
      <img :src="getAssetPath('media/custom/check_circle.svg')" alt="success" />
    </div>
    <div class="message_wrapper">
      <h6>Your email has been verified successfully.</h6>
    </div>
    <div class="btn_wrapper">
      <button class="btn btn-primary text-uppercase w-100">next</button>
    </div>
  </div>
</template>
<script lang="ts">
import {getAssetPath} from "../../utils/AssetPath"
import { defineComponent } from "vue";
import { useRouter } from "vue-router";
export default defineComponent({
  name: "account-created",
  setup() {
    const router = useRouter();
    const goVerifyPhoneOTP = () => {
      router.push({ name: "email-otp" });
    };
    return {
      getAssetPath,
      goVerifyPhoneOTP,
    };
  },
});
</script>
