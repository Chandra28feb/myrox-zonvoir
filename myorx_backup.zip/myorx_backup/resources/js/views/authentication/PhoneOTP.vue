<template>
  <!--begin::Wrapper-->
  <AuthSide :side-full-img="phone_otp" />
  <div class="righ_section_auth_wrapper order-2">
    <div class="sign_up_wrapper">
      <AuthTitle title="Phone OTP Verification" description="To Phone OTP verification, Please enter the verification code below." />
      <div v-if="serverMessage">
        <AlertBox :message="serverMessage"/>
      </div>
        <div class="otp_wrapper ">
          <p>Verification code</p>
          <OTP @handleOTPData="handleOTPDataCallback" @handleOTPChanged="handleOTPChangedCallback" />
          <div v-if="isOtpValid"  class="kk_message_container">
            <div class="kk-help-block">
              <span>
                Otp field is required
              </span>
            </div>
          </div>
        </div>
  
        <!--begin::Input group-->
        <div class="row">
          <div class="col-xl-12">
            <p
              class="other_link"
            >
              Didn’t get a code?
              <a @click="resendPhoneOTP" :class="['link-primary fw-700',ResendLoading?'disabled_link':'']">
                Click to resend <span v-if="ResendLoading" class="d-inline-block"><Loader/> </span>
              </a>
            </p>
          </div>
          <div class="col-xl-12 mb-3">
            <p
              class="form-check-label other_link fw-semobold mb-1 other_link fs-6"
            >
              <router-link to="/" class="link-primary d-flex align-items-center">
                Back To myoRX
                <span class="pl-3">
                  <i class="fa-sharp fa-solid fa-house"></i>
                </span>
              </router-link>
            </p>
          </div>
          <div class="col-lg-12">
            <button
            @click="goVerifyPhoneOTP"
            type="button"
            class="btn btn-lg btn-primary btn_cus_primary w-100"
            :disabled="loading"
          >
            <span v-if="!loading" class="indicator-label"> verify </span>
            <span v-else class="indicator-progress">
              Please wait...
              <span
                class="spinner-border spinner-border-sm align-middle ms-2"
              ></span>
            </span>
          </button>
          </div>
        </div>
  
      </div>
  </div>
  <!-- modal -->
 <OtpConfirmModal ref="thisModal"/>
  <!--  -->

  <!-- end:: wrapper-->
</template>
<script setup>
import AuthTitle from "./components/AuthTitle.vue"
import AuthSide from "./components/AuthSide.vue";
import phone_otp from "@/assets/custom/phone_otp.svg"
import OTP from "./OTP.vue";
import { ref} from "vue";
import OtpConfirmModal from "./components/OtpConfirmModal.vue";
import { errorHandler } from "@/js/utils/ErrorHandler";
import ApiBase from "@/js/services/ApiBase";
import { getToken } from "@/js/services/Jwt";
import {sendPhoneOTP}  from"@/js/utils/sendOTP"
import { useRouter } from "vue-router";
import { checkAuth } from "@/js/utils/common";
import Loader from "@/js/components/loader/Loader.vue";
import AlertBox from "@/js/components/AlertBox.vue";
const router = useRouter();
const { isUser,isPhoneVerified, userRole } = checkAuth();
console.log(!isPhoneVerified)
const loggedPanel = (userRole === "Patient") ? "patient" : "dashboard";
!isPhoneVerified ? '' : router.push({name:loggedPanel});
let serverMessage= ref(null);
    let otpValue = $ref(null);
    let isOtpValid = $ref(null);
    let loading = $ref(null);
    let ResendLoading = ref(null);
    let thisModal= ref(null);
    const resendPhoneOTP = async () =>{
      serverMessage.value='';
      ResendLoading.value=true
      const {message, loadingRes } = await sendPhoneOTP();
        loadingRes?'':ResendLoading.value = loadingRes;
        message ? serverMessage.value = message :''
    }
    const goVerifyPhoneOTP = async () => {
      serverMessage.value='';
      if(otpValue?.length===6){
        isOtpValid = false;
        loading  = true;
       await ApiBase.create('sms-otp-verification', {verification_code: otpValue})
       .then(({ data }) => {
        if(data){
          thisModal.value.show();
        }
        })
        .catch(({ response }) => {
          if(response){
                serverMessage.value = errorHandler(response);
            }
        })
        .finally(()=>{
       loading  = false;
     });
    } else{
      isOtpValid = true;
    }
    }
    const handleOTPDataCallback = ($event) => {
      if ($event) {
         otpValue = $event
         isOtpValid = false;
        } else {
        isOtpValid = true;
       }
    };
    const handleOTPChangedCallback = (otpChangeData) =>{
      if (otpChangeData) {
         otpValue = otpChangeData
         otpChangeData.length===0 ? isOtpValid = true : isOtpValid = false;
      }
    }

</script>

