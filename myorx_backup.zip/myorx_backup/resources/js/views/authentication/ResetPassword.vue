<template>
  <!--begin::Wrapper-->
  <AuthSide :side-full-img="newPassImg" />
  <div class="righ_section_auth_wrapper order-2">
    <div class="sign_up_wrapper">
      <AuthTitle title="Create New Password" description="It happens all of us. Let’s help you out." />
      <div class="_form_wraper">
        <ResetPasswordForm />
      </div>
    </div>
  </div>

  <!--end::Wrapper-->
</template>

<script setup>
import AuthTitle from "./components/AuthTitle.vue"
import AuthSide from "./components/AuthSide.vue";
import ResetPasswordForm from "./components/ResetPasswordForm.vue";
import newPassImg from "@/assets/custom/create_new_pass.svg"

</script>
