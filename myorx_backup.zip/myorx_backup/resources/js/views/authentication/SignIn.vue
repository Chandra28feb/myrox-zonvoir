<template>
  <!--begin::Wrapper-->
      <AuthSide :side-full-img="loginImg" />
    <div class="righ_section_auth_wrapper order-2">
      <div class="sign_up_wrapper">
        <AuthTitle title="Login Now !" description="We connect patients with doctors online to help them get and stay
        healthy." />
        <div class="py-2 mb-3">
          <p
          class="other_link"
        >
          Don’t have an account?
          <router-link to="/register" class="link-primary fw-700">
            Sign Up
          </router-link>
        </p>
        </div>
        <!-- <div class="or_signup">
          <span>or</span>
        </div> -->
        <div class="">
          <LoginForm />
        </div>
      </div>
    </div>

  <!--end::Wrapper-->
</template>

<script setup>
import AuthSide from "./components/AuthSide.vue";
import AuthTitle from "./components/AuthTitle.vue"
import LoginForm from "./components/LoginForm.vue";
import loginImg from "@/assets/custom/login.svg"
</script>
