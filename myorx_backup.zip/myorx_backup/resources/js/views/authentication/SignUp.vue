
<script setup>
import AuthTitle from "./components/AuthTitle.vue"
import SignUpForm from "./components/SignUpForm.vue";
import AuthSide from "./components/AuthSide.vue";
 import signupImg from "@/assets/custom/Sign_up.svg";
</script>
<template>
  <!--begin::Wrapper-->
  <AuthSide :side-full-img="signupImg" />
  <div class="righ_section_auth_wrapper order-2">
    <div class="sign_up_wrapper">
      <AuthTitle title="Create an Account" description=" We connect patients with doctors online to help them get and stay
      healthy." />
      <div class="py-2 mb-3">
        <p
          class="other_link"
        >
        Already have an account?
          <router-link to="/login" class="link-primary fw-700">
            Log In
          </router-link>
        </p>
      </div>
      <div class="">
        <SignUpForm />
      </div>
    </div>
  </div>
  <!--end::Wrapper-->
</template>
