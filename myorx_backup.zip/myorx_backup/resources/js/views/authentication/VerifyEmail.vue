<template>
  <!--begin::Wrapper-->

  <!-- verify_email -->
  <AuthSide :side-full-img="verify_email" />
  <div class="righ_section_auth_wrapper order-2">
    <div class="sign_up_wrapper">
      <AuthTitle title="Verify Your Email"  />
      <div v-if="serverMessage">
        <AlertBox :message="serverMessage"/>
      </div>
      <div class="open_gmail_wrap">
        <a
          href="https://mail.google.com/mail/?view=cm&fs="
          class="gmail_btn"
          target="_blank"
        >
          <img
            :src="gmailLogo"
            style="width: 20px; height: 20px"
            alt="Gmail"
          />
          Open Gmail
        </a>
        <p>We have send and email to <a href="" v-if="userEmail">{{userEmail}}</a></p>
      </div>
      <div class="email_veri_message">
        <p>
          If you have not received the recovery email, please check your “Spam”
          or “Bulk Email” folder. You can also click the resend button below to
          have another email send to you.
        </p>
      </div>

      <!--begin::Actions-->
      <div class="row mb-4">
        <div class="col-xl-12">
          <button
          ref="submitButton"
          type="submit"
          class="btn btn-lg btn-primary btn_cus_primary customize_btn w-100"
          @click="resendEmail()"
          >
          <span class="indicator-label"> Resend Recovery Email </span>
          <span class="indicator-progress">
            Please wait...
            <span
              class="spinner-border spinner-border-sm align-middle ms-2"
            ></span>
          </span>
        </button>
        </div>
      </div>

      <!--begin::Input group-->
      <div class="row">
        <div class="col-xl-12">
          <BaseLink page-link="/" link-title="Back To myoRX" :imgIcon="HomeIcon" />
        </div>
        <div class="col-xl-12">
          <p
            class="form-check-label other_link fw-semobold text-primary-700 mb-1 other_link fs-6"
          >
            Don’t have an account?
            <router-link to="/register" class="link-primary fw-bold">
              Sign Up
            </router-link>
          </p>
        </div>
      </div>
      <!--end::Input group-->

      <!--end::Actions-->
    </div>
  </div>
  <!-- end:: wrapper-->
</template>
<script setup>
import AuthTitle from "./components/AuthTitle.vue"
import AuthSide from "./components/AuthSide.vue";
import HomeIcon from "@/assets/icons/home_outline.svg"
import BaseLink from "@/js/components/links/BaseLink.vue";
import SubmitBtn from "@/js/components/buttons/SubmitBtn.vue";
import gmailLogo from "@/assets/custom/gmail.svg"
import verify_email from "@/assets/custom/verify_email.svg"
import { ref,onMounted } from "vue";
import { isObjectEmpty } from "@/js/utils/common";
import { useRouter } from "vue-router";
import { destroyToken, getSessionToken } from "@/js/services/Jwt";
import { sendRecoveryEmail } from"@/js/utils/sendOTP";
import AlertBox from "@/js/components/AlertBox.vue";
const router = useRouter();
let serverMessage= ref(null);
const submitButton = ref(null);
 let userEmail = ref(null);

 onMounted(()=>{
  const sessionData = JSON.parse(getSessionToken());
  console.log(sessionData,isObjectEmpty(sessionData));
  if(!isObjectEmpty(sessionData)==null){
    userEmail.value = sessionData.s4874bc701a33
  }
  destroyToken();
})

const resendEmail = async() => {
  if (submitButton.value) {
        submitButton.value.disabled = true;
        submitButton.value.setAttribute("data-kk-indicator", "on");
      }
  const { message, loadingRes } = await sendRecoveryEmail({email:'kuldip@zonvoir.com'});
  if(!loadingRes){
    submitButton.value.disabled = false;
    submitButton.value.removeAttribute("data-kk-indicator", "on");
  }
  message?serverMessage.value=message:'';
  
}
</script>
