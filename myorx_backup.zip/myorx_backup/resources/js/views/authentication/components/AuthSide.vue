<script setup>
const props = defineProps({
  sideFullImg:String
  
})
</script>
<template>
      <div
    class="d-flex auth_wrapper_img order-1 order-lg-1"
    :style="`background-image: url('${sideFullImg}')`"
  ></div>
  <!-- :style="`background-image: url('${fullImg}')`" -->
  <!-- style="background-image: url('../../../assets/custom/login.svg')" -->
</template>