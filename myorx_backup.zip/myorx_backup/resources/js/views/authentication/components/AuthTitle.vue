<script setup>
const props = defineProps({
    title:String,
    subTitle:String,     
    description:String,
})
</script>
<template>
    <div class="form_title">
        <h3 v-if="title">{{title}}</h3>
        <h6 v-if="subTitle">{{subTitle}}</h6>
        <p v-if="description" class="pb-1">{{description}}</p>
      </div>
      
</template>