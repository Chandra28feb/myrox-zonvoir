<script setup>
import {  ref,onMounted  } from "vue";
import { ErrorMessage, Field, Form as VForm } from "vee-validate";
import * as Yup from "yup";
import { useRouter } from "vue-router";
import BaseLink from "@/js/components/links/BaseLink.vue";
import HomeIcon from "@/assets/icons/home_outline.svg"
import { sendRecoveryEmail } from"@/js/utils/sendOTP";
import { removeSpace } from "@/js/utils/common";
import AlertBox from "@/js/components/AlertBox.vue";
let loading = $ref(null);
let serverMessage= ref(null);
const submitButton = ref(null);
const router = useRouter();
    const forgotPassword = Yup.object().shape({
      email: Yup.string().required().email().label("Email"),
    });
    
    const onForgotPassword = async (values) => {
      serverMessage.value='';
      loading  = true;
      if (submitButton.value) {
        submitButton.value.disabled = true;
        submitButton.value.setAttribute("data-kk-indicator", "on");
      }
      const updatedValues = removeSpace(values)
      console.log(updatedValues);
      const {message, loadingRes }= await sendRecoveryEmail(updatedValues);
          if(!loadingRes){
            submitButton.value?.removeAttribute("data-kk-indicator");
            submitButton.value.disabled = false;
          }
          message?serverMessage.value=message:''
    };
</script>
<template>
  <div v-if="serverMessage">
    <AlertBox :message="serverMessage"/>
  </div>
    <VForm
    v-slot="{ errors }"
    class="form w-100"
    novalidate
    
    @submit="onForgotPassword"
    id="kt_login_signup_form"
    :validation-schema="forgotPassword"
  >
    <!--begin::Input group-->
    <div class="row mb-7">
      <!--begin::Col-->
      <div class="col-xl-12">
        <div class="custom_inp_wrap">
          <label class="form-label "
            >Email Address*</label
          >
          <Field
            class="form-control form-control-lg form-control-solid custom_input"
            type="email"
            placeholder=""
            name="email"
            autocomplete="off"
            v-focus
          />
          <div v-if="errors.email" class="kk_message_container">
            <div class="kk-help-block">
              <ErrorMessage name="email" />
            </div>
          </div>
        </div>
      </div>
      <!--end::Col-->
    </div>
    <!--begin::Actions-->
    <div class=" row">
      <div class="col-xl-12 mb-4">
        <button
        ref="submitButton"
        type="submit"
        class="btn btn-lg btn-primary btn_cus_primary customize_btn w-100"
        >
        <!-- :disabled="loading" -->
        <span class="indicator-label"> send </span>
        <span class="indicator-progress">
          Please wait...
          <span
            class="spinner-border spinner-border-sm align-middle ms-2"
          ></span>
        </span>
      </button>
       

      </div>
    </div>

    <!--end::Actions-->
    <!--begin::Input group-->
    <div class="privacy_policy row">
      <div class="col-xl-12">
        <BaseLink page-link="/" link-title="Back To myoRX" :imgIcon="HomeIcon" />
      </div>
      <div class="col-xl-12 mb-2">
        <p
          class="form-check-label fw-semobold text-primary-700 mb-1 other_link fs-6"
        >
          Don’t have an account?
          <router-link to="/register" class="link-primary fw-bold">
            Sign Up
          </router-link>
        </p>
      </div>
    </div>
    <!--end::Input group-->
  </VForm>
</template>