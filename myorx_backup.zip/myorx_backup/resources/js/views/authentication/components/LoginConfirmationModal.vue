<script setup>
import check_circle from "@/assets/custom/check_circle.svg"
import ApiBase from "@/js/services/ApiBase";
import { errorHandler } from "@/js/utils/ErrorHandler";
import { useRouter } from "vue-router";
import { onMounted, ref } from "vue";
import { Modal } from "bootstrap";
    const props = defineProps({
        title:{
            type:String,
            default:''
        },
    });
    let modalEle = ref(null);
let thisModalObj = null;
onMounted(() => {
  thisModalObj = new Modal(modalEle.value);
});
function _show() {
  thisModalObj.show();
}
    let loading = $ref(false); 

    const router = useRouter();
    const verifyNow = (pageVal) => {
      if(  pageVal ==='email address'){
        router.push({ name: 'email-otp' })
      }else{
        router.push({ name: 'phone-otp' })
      }
      thisModalObj.hide();
    };
    defineExpose({ show: _show });
</script>
<template>
    <div  ref="modalEle" class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl">
          <div class="modal-content cus_modal_content">
            <div class="modal-body cus_modal_body">
              <div class="main_message_wraper">
                <div class="success_full_verification">
                  
                    <div class="message_wrapper">
                      <h6>Your {{title}} is not verified !</h6>
                      <div class="my-2">
                        <p>Please verify your {{title}}  first .</p>
                      </div>
                    </div>
                    <div class="btn_wrapper">
                      <button
                      :disabled="loading"
                      @click="verifyNow(title)"
                      type="button"
                      class="btn btn-lg btn-primary btn_cus_primary w-100"
                    >
                      <span v-if="!loading" class="indicator-label"> verify </span>
                      <span v-else class="indicator-progress">
                        Please wait...
                        <span
                          class="spinner-border spinner-border-sm align-middle ms-2"
                        ></span>
                      </span>
                    </button>
                    </div>
                  </div>
              </div>
            </div>
          </div>
        </div>
      </div>
 
    <!-- Modal -->

  </template>