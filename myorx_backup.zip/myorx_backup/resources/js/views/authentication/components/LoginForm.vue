<script setup>
import { ref, onMounted } from "vue";
import { ErrorMessage, Field, Form as VForm } from "vee-validate";

import { useRouter } from "vue-router";
import BaseLink from "@/js/components/links/BaseLink.vue";
import { saveToken,destroyToken } from "@/js/services/Jwt";
import ApiBase from "@/js/services/ApiBase";
import { errorHandler } from "@/js/utils/ErrorHandler"
import eye from "@/assets/icons/eye.svg";
import eye_off from "@/assets/icons/eye-off.svg";

import LoginConfirmationModal from "./LoginConfirmationModal.vue";
import { removeSpace } from "@/js/utils/common";
import { loginValidation } from "@/js/views/authentication/validations/signInValidation";
import AlertBox from "@/js/components/AlertBox.vue";
let loading = $ref(false);
let isHidden= $ref(true);
let nonVerifiedPage= $ref('');
let passwordType = $ref("password");
let thisModal= ref(null);
let loginSigInForm = ref(null);
let loginSigInFormObj = null;
let emailEle = ref(null);
let serverMessage= ref(null);

onMounted(()=>{
  // emailEle.value.focus()
  loginSigInFormObj = loginSigInForm.value;
  destroyToken();
})
const togglePasswordType = () =>{
  isHidden = !isHidden;
  passwordType = isHidden ? "password" : "text";
    }
    const router = useRouter();
    let loginForm = loginValidation();
    const onSubmitLogin = (values) => {
      loading=true;
      serverMessage.value='';
      const updatedValues = removeSpace(values);
      ApiBase.create('login',updatedValues)
      .then(({ data }) => {
        if(data){
          const user= data.success.user;
          
          const userData = {
            "ta3e1dfhdih236cau":data.success.token,
            "ur3da23ed4lbdd0be":data.userRole.join(),
            "m82fe136sd33333ca":user.is_mobile_verified,
            "e25e13612237df24k":user.is_email_verified,
          }
            saveToken(JSON.stringify(userData));
            if(user.is_mobile_verified&&user.is_email_verified){
              data.userRole.join() === "Patient" ? router.push({ name: "patient" }) : router.push({ name: "dashboard" });
              
            }
            else if(!user.is_mobile_verified){
              thisModal.value.show();
              nonVerifiedPage = "phone number"
            }
            else if(!user.is_email_verified){
              thisModal.value.show();
              nonVerifiedPage = "email address"
            }
        }
        })
        .catch(({ response }) => {
            if(typeof response.data.error === 'object'){
              loginSigInFormObj.setErrors({...response.data.error})
            }else{
              serverMessage.value = errorHandler(response);
            }
        })
        .finally(()=>{
          loading = false;
        });
    };


</script>
<template>
  <div v-if="serverMessage">
    <AlertBox :message="serverMessage"/>
  </div>
    <VForm
    v-slot="{ errors }"
    ref="loginSigInForm"
    class="form w-100 fv-plugins-bootstrap5 fv-plugins-framework"
    novalidate
    @submit="onSubmitLogin"
    autocomplete="false"
    id="kt_login_signup_form"
    :validation-schema="loginForm"
  >
    <!--begin::Input group-->
    <div class="row fv-row mb-7">
      <!--begin::Col-->
      <div class="col-xl-12">
        <div class="custom_inp_wrap">
          <label class="form-label"
            >Email Address*</label
          >
          <Field
          ref="emailEle"
            class="form-control form-control-lg form-control-solid custom_input"
            type="email"
            placeholder=""
            name="email"
            autocomplete="false"
            role="presentation"
            v-focus
            />
          <div v-if="errors.email" class="kk_message_container">
            <div class="kk-help-block">
              <ErrorMessage name="email" />
            </div>
          </div>
        </div>
      </div>
      <!--end::Col-->
    </div>

    <!-- end input group -->
    <div class="row fv-row mb-7">
      <!--begin::Col-->
      <div class="col-xl-12">
        <div class="custom_inp_wrap">
          <label class="form-label "
            >Password*</label
          >
          <Field
            class="form-control form-control-lg form-control-solid password_input custom_input"
            :type="passwordType"
            placeholder=""
            name="password"
            autocomplete="off"
            />
          <div class="eye_input" @click="togglePasswordType">
            <img  v-if="isHidden" :src="eye_off" alt="icon" />
            <img v-else :src="eye" alt="icon" />
          </div>
          <div v-if="errors.password" class="kk_message_container">
            <div class="kk-help-block">
              <ErrorMessage name="password" />
            </div>
          </div>
        </div>
      </div>
      <!--end::Col-->
    </div>
    <div class="fv-row mb-3">
      <div class="col-xl-12">
          <button
          :disabled="loading"
            type="submit"
            class="btn btn-lg btn-primary btn_cus_primary w-100"
          >
            <span v-if="!loading" class="indicator-label"> Submit </span>
            <span v-else class="indicator-progress">
              Please wait...
              <span
                class="spinner-border spinner-border-sm align-middle ms-2"
              ></span>
            </span>
          </button>
      </div>
    </div>

    <!--end::Actions-->
    <!--begin::Input group-->
    <div class="row">
      <div class="col-xl-12">
        <BaseLink page-link="/forgot-password" link-title="Forgot Password ?" />
      </div>
    </div>
    <!--end::Input group-->
  </VForm>
  <LoginConfirmationModal :title="nonVerifiedPage" ref="thisModal" />
</template>
