<script setup>
import check_circle from "@/assets/custom/check_circle.svg"
import ApiBase from "@/js/services/ApiBase";
import { errorHandler } from "@/js/utils/ErrorHandler";
import { useRouter } from "vue-router";
import { onMounted, ref } from "vue";
import { Modal } from "bootstrap";
import { checkAuth } from "@/js/utils/common";
import { getToken, saveToken } from "@/js/services/Jwt";
    const props = defineProps({
        title:{
            type:String,
            default:'phone number'
        },
        nextPage:{
            type:String,
            default:'email-otp'
          }
        });
        
        let modalEle = ref(null);
        let thisModalObj = null;
        const { isEmailVerified, userRole } = checkAuth();
        onMounted(() => {
          thisModalObj = new Modal(modalEle.value);
        });

        const router = useRouter();
    const nextStep = (pageVal) => {
      if(  pageVal ==='email'){
        const loggedUser = JSON.parse(getToken()); 
  
          loggedUser.e25e13612237df24k = true;
          
            saveToken(JSON.stringify(loggedUser));
        thisModalObj.hide();
        userRole === "Patient" ? router.push({ name: "patient" }) : router.push({ name: "dashboard" });
        // router.push({ name: 'identity-verification' })
      }else{
        requestForEmail();
      }
    };
function _show() {
  thisModalObj.show();
}
    let loading = $ref(false); 
     const requestForEmail = () => {
      loading  = true;
      ApiBase.getAll('send-verification-email')
      .then(({data}) =>{
        if (data) {
          console.log('res kk',data);
          const loggedUser = JSON.parse(getToken()); 

          loggedUser.m82fe136sd33333ca = true;
          
          saveToken(JSON.stringify(loggedUser));
          thisModalObj.hide();
          if(isEmailVerified){
            userRole === "Patient" ? router.push({ name: "patient" }) : router.push({ name: "dashboard" });
          }else{
            router.push({ name: 'email-otp' })
          }
        }
      })
      .catch(({response}) =>{
        if(response){
            console.log("err", response );
            message = errorHandler(response);
        }
      })
      .finally(()=>{
          loading  = false;
        });
      }
  
    defineExpose({ show: _show });
</script>
<template>
    <div  ref="modalEle" class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl">
          <div class="modal-content cus_modal_content">
            <div class="modal-body cus_modal_body">
              <div class="main_message_wraper">
                <div class="success_full_verification">
                    <div class="success_mark">
                      <img :src="check_circle" alt="success" />
                    </div>
                    <div class="message_wrapper">
                      <h6>Your {{title}} has been verified successfully.</h6>
                    </div>
                    <div class="btn_wrapper">
                      <button
                      :disabled="loading"
                      @click="nextStep(title)"
                      type="button"
                      class="btn btn-lg btn-primary btn_cus_primary w-100"
                    >
                      <span v-if="!loading" class="indicator-label"> Continue </span>
                      <span v-else class="indicator-progress">
                        Please wait...
                        <span
                          class="spinner-border spinner-border-sm align-middle ms-2"
                        ></span>
                      </span>
                    </button>
                    </div>
                    <p v-if="title==='phone number'" >Please verify your email address on next screens.</p>
                  </div>
              </div>
            </div>
          </div>
        </div>
      </div>
 
    <!-- Modal -->

  </template>
