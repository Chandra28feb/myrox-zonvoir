<script setup>
import { ref } from "vue";
import { ErrorMessage, Field, Form as VForm } from "vee-validate";
import { useRouter } from "vue-router";
import { errorHandler } from "@/js/utils/ErrorHandler";
import ApiBase from "@/js/services/ApiBase";
import eye from "@/assets/icons/eye.svg";
import eye_off from "@/assets/icons/eye-off.svg";
import { resetPasswordValidation } from "../validations/signInValidation";
import { removeSpace } from "@/js/utils/common";
import { onMounted  } from "vue";
import { isObjectEmpty } from "@/js/utils/common";
import AlertBox from "@/js/components/AlertBox.vue";
const router = useRouter();
let resetPasswordData = $ref(null);
let resetForm = ref(null);
let resetFormObj = null;
let serverMessage= ref(null);

onMounted(() => {
  resetFormObj = resetForm.value;
});
onMounted(()=>{
  if(isObjectEmpty(router.currentRoute._value.query)){
    router.push({ name: "login" });
  }else{
    resetPasswordData = router.currentRoute._value.query
  }
})

let loading = $ref(null);
      let isHidden = $ref(true);
      let isHiddenC = $ref(true);
      let passwordTypeC = $ref("password");
      let passwordType = $ref("password");

      const togglePasswordType = () =>{
      isHidden = !isHidden;
      passwordType = isHidden ? "password" : "text";
    }
      const togglePasswordTypeC = () =>{
      isHiddenC = !isHiddenC;
      passwordTypeC = isHiddenC ? "password" : "text";
    }
    const passwordReset = resetPasswordValidation();

    const onSubmitForm =  (values) => {
      serverMessage.value='';
      const newValues = {
        ...resetPasswordData,
        ...values,
      };
      const updatedValues = removeSpace(newValues);
      loading  = true;
      ApiBase.create('reset-password',updatedValues)
          .then(({ data }) => {
            if(data){
              console.log("res", data)
              loading  = false;
              router.push({ name: "password-updated" });
            }
          })
          .catch(({ response }) => {
                  console.log("err", response);
                  if(typeof response.data.error === 'object'){
                  resetFormObj.setErrors({...response.data.error})
                }else{
                  serverMessage.value = errorHandler(response);
                }
              })
          .finally(()=>{
              loading = false;
              console.log('finally', loading)
          });
    };
</script>
<template>
  <div v-if="serverMessage">
    <AlertBox :message="serverMessage"/>
  </div>
    <VForm
    v-slot="{ errors }"
    ref="resetForm"
    class="form w-100 fv-plugins-bootstrap5 fv-plugins-framework"
    novalidate
    @submit="onSubmitForm"
    id="kt_login_signup_form"
    :validation-schema="passwordReset"
  >
    <!--begin::Input group-->
    <div class="row mb-7">
      <!--begin::Col-->
      <div class="col-xl-12">
        <div class="custom_inp_wrap">
          <label class="form-label"
            >Password*</label
          >
          <Field
            class="form-control form-control-lg form-control-solid password_input custom_input"
            :type="passwordType"
            placeholder=""
            name="password"
            autocomplete="off"
            v-focus
          />
          <div class="eye_input" @click="togglePasswordType">
            <img  v-if="isHidden" :src="eye_off" alt="icon" />
            <img v-else :src="eye" alt="icon" />
          </div>
          <div v-if="errors.password" class="kk_message_container">
            <div class="kk-help-block">
              <ErrorMessage name="password" />
            </div>
          </div>
        </div>
      </div>
      <!--end::Col-->
    </div>
    <!--end::Input group-->
    <div class="row mb-7">
      <!--begin::Col-->
      <div class="col-xl-12">
        <div class="custom_inp_wrap">
          <label class="form-label"
            >Confirm Password*</label
          >
          <Field
            class="form-control form-control-lg form-control-solid password_input custom_input"
            :type="passwordTypeC"
            placeholder=""
            name="password_confirmation"
            autocomplete="off"
          />
          <div class="eye_input" @click="togglePasswordTypeC">
            <img  v-if="isHiddenC" :src="eye_off" alt="icon" />
            <img v-else :src="eye" alt="icon" />
          </div>
          <div v-if="errors.password_confirmation" class="kk_message_container">
            <div class="kk-help-block">
              <ErrorMessage name="password_confirmation" />
            </div>
          </div>
        </div>
      </div>
      <!--end::Col-->
    </div>
    <div class="row ">
      <div class="col-xl-12">
        <button
        type="submit"
        class="btn btn-lg btn-primary btn_cus_primary w-100"
        :disabled="loading"
      >
        <span v-if="!loading" class="indicator-label"> submit </span>
        <span v-else class="indicator-progress">
          Please wait...
          <span
            class="spinner-border spinner-border-sm align-middle ms-2"
          ></span>
        </span>
      </button>
      </div>
    </div>

    <!--end::Actions-->
  </VForm>
</template>