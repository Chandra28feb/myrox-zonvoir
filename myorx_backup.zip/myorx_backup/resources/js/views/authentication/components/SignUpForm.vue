<script setup>
import { ref,onMounted,watch, reactive  } from "vue";
import { ErrorMessage, Field, Form as VForm } from "vee-validate";
import Multiselect from "@vueform/multiselect";
import { useRouter } from "vue-router";
import eye from "@/assets/icons/eye.svg";
import eye_off from "@/assets/icons/eye-off.svg";
import usFlag from "@/assets/custom/usa_flag.svg"
import ApiBase from "@/js/services/ApiBase"
import { destroyToken, saveToken } from "@/js/services/Jwt";
import { errorHandler } from "@/js/utils/ErrorHandler";
import { removeSpace } from "@/js/utils/common";
import { signUpValidations } from "@/js/views/authentication/validations/signUpValidation";
import AlertBox from "@/js/components/AlertBox.vue";
import { vMaska } from "maska";
const router = useRouter();
const mobileElement = ref();
// const custom_mobile = ref(null);
// const my_number = reactive({
//   mobile:''
// });
// const cu/stom_mobile = '';
// let mobileError = ref(null);
let value = ref(null);
let loading = $ref(false);
let defaultCountry = $ref('+1');
let options = ref(["Friends", "Social Media", "Others"]);
let isHidden= $ref(true);
let passwordType = $ref("password");
let signupForm = ref(null);
let signUpFromObj = null;
let isHiddenC = $ref(true);
let passwordTypeC = $ref("password");
let firstNameEle = ref(null);
let serverMessage= ref(null);
onMounted(() => {
  signUpFromObj = signupForm.value;
  // destroyToken();
});

const togglePasswordType = () =>{
      isHidden = !isHidden;
      passwordType = isHidden ? "password" : "text";
    }
const togglePasswordTypeC = () =>{
      isHiddenC = !isHiddenC;
      passwordTypeC = isHiddenC ? "password" : "text";
    }
  let registration = signUpValidations();
    const onSubmitRegister = (values) => {
      serverMessage.value='';
      loading =true;
      const updatedValues = removeSpace(values);
      updatedValues['mobile_no'] = updatedValues['mobile_no'].replace(/[^a-zA-Z0-9 ]/g, '');
      ApiBase.create('signup',updatedValues)
      .then(({ data }) => {
        if(data){
          console.log('rsss',data);
          const user= data.success.user;
          const userData = {
            "ta3e1dfhdih236cau":data.success.token,
            "u56b4dd0b404d09e1":user.id,
            "m82fe136sd33333ca":user.is_mobile_verified,
            "e25e13612237df24k":user.is_email_verified,
          }
          saveToken(JSON.stringify(userData));
          router.push({ name: "account-created" });
        }
      })
      .catch(({ response }) => {
            if(typeof response.data.error === 'object'){
              signUpFromObj.setErrors({...response.data.error})
            }else{
              serverMessage.value = errorHandler(response);

            }
        })
        .finally(()=>{
          loading = false;
        });
    };
</script>

<template>
  <div v-if="serverMessage">
    <AlertBox :message="serverMessage"/>
  </div>
    <VForm
    v-slot="{ errors }"
    class=""
    ref="signupForm"
    novalidate
    @submit="onSubmitRegister"
    :validation-schema="registration"
    autocomplete="off"
  >
    <!--begin::Input group-->
    <div class="name_box mb-7">
      <!--begin::Col-->
      <div class="custom_inp_wrap name_field_wrapper">
        <label class="form-label"
          >First Name*</label
        >
        <Field
        ref="firstNameEle"
          class="form-control form-control-lg form-control-solid custom_input"
          type="text"
          placeholder=""
          name="first_name"
          autocomplete="off"
          v-focus
        />
        <div v-if="errors.first_name" class="kk_message_container name_inputs">
          <div class="kk-help-block">
            <ErrorMessage name="first_name" />
          </div>
        </div>
      </div>
      <div class="custom_inp_wrap name_field_wrapper">
        <label class="form-label">Last Name*</label>
        <Field
          class="form-control form-control-lg form-control-solid custom_input"
          type="text"
          placeholder=""
          name="last_name"
          autocomplete="off"
        />
        <div v-if="errors.last_name" class="kk_message_container name_inputs">
          <div class="kk-help-block">
            <ErrorMessage name="last_name" />
          </div>
        </div>
      </div>
    </div>
    <!-- end input group -->
    <!--begin::Input group-->
    <div class="row mb-7">
      <!--begin::Col-->
      <div class="col-lg-12">
        <div class="custom_inp_wrap">
          <label class="form-label"
            >Email Address*</label
          >
          <Field
            class="form-control form-control-lg form-control-solid custom_input"
            type="email"
            placeholder=""
            name="email"
            autocomplete="off"
          />
          <div  class="kk_message_container">
            <div class="kk-help-block">
              <ErrorMessage name="email" />
            </div>
          </div>
        </div>
      </div>
      <!--end::Col-->
    </div>
    <!-- end input group -->
    <div class="row mb-7">
      <div class="col-lg-12">
        <div class="custom_inp_wrap">
          <label class="form-label"
            >Phone Number*</label
          >
        <Field
            class="form-control form-control-lg form-control-solid custom_input phone_input"
            type="text"
            placeholder=""
            name="mobile_no"
            autocomplete="off"
            ref="mobileElement"
            v-maska data-maska="(###) ###-####"
            />
          <div class="k_selected_option">
            <img class="flag-icon" :src="usFlag"> {{ defaultCountry }} 
          </div>
          <div  class="kk_message_container">
            <div class="kk-help-block">
              <ErrorMessage name="mobile_no" />
            </div>
          </div>
        </div>

      </div>
      <!--end::Col-->
    </div>
    <!-- end input group -->
    <div class="row mb-7">
      <!--begin::Col-->
      <div class="col-lg-12">
        <div class="custom_inp_wrap">
          <label class="form-label"
            >How did you hear about MYO?</label
          >
          <Field name="referred_by" v-slot="{field}">
            <Multiselect
            v-bind="field"
              placeholder="Select One.."
              class="multi_select_input"
              v-model="value"
              :options="options"
            />
          </Field>
        </div>
      </div>
    
      <!--end::Col-->
    </div>
    <div class="row mb-7">
      <!--begin::Col-->
      <div class="col-lg-12">
        <div class="custom_inp_wrap">
          <label class="form-label"
          >Password*</label
          >
          <Field
            class="form-control form-control-lg form-control-solid password_input custom_input"
            :type="passwordType"
            placeholder=""
            name="password"
            autocomplete="off"
          />
          <div class="eye_input" @click="togglePasswordType">
            <img  v-if="isHidden" :src="eye_off" alt="icon" />
            <img v-else :src="eye" alt="icon" />
          </div>
          <div  class="kk_message_container">
            <div class="kk-help-block">
              <ErrorMessage name="password" />
            </div>
          </div>
        </div>
      </div>
      <!--end::Col-->
    </div>
    <div class="row mb-7">
      <div class="col-lg-12">
        <div class="custom_inp_wrap">
          <label class="form-label"
            >Confirm Password*</label
          >
          <Field
            class="form-control form-control-lg form-control-solid password_input custom_input"
            :type="passwordTypeC"
            placeholder=""
            name="password_confirmation"
            autocomplete="off"
          />
          <div class="eye_input" @click="togglePasswordTypeC">
            <img  v-if="isHiddenC" :src="eye_off" alt="icon" />
            <img v-else :src="eye" alt="icon" />
          </div>
          <div  class="kk_message_container">
            <div class="kk-help-block">
              <ErrorMessage name="password_confirmation" />
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--end::Input group-->
    <div class="row ">
      <div class="col-lg-12 mb-3">
        <label class="custom_checkbox">
          <div>
            <Field
              class="form-check-input"
              type="checkbox"
              name="terms_and_conditions"
              value="1"
            />
          </div>
          <span
            class="form_check_label text_primary"
          >
          Creating an account means you agree with our Terms of Service
          Privacy Policy and our default Notification Settings.
          </span>
        </label>
        <div v-if="errors.terms_and_conditions" class="kk_message_container">
          <div class="kk-help-block">
            <ErrorMessage name="terms_and_conditions" />
          </div>
        </div>
        
      </div>
      <div class="col-lg-12 mb-3">
        <div class="text-center mb-1">
          <button
          :disabled="loading"
            type="submit"
            class="btn btn-lg btn-primary btn_cus_primary w-100"
          >
            <span v-if="!loading" class="indicator-label"> Submit </span>
            <span v-else class="indicator-progress">
              Please wait...
              <span
                class="spinner-border spinner-border-sm align-middle ms-2"
              ></span>
            </span>
          </button>
        </div>
      </div>
    </div>
  </VForm>
</template>
<style src="@vueform/multiselect/themes/default.css"></style>
<style lang="scss">
</style>