import * as Yup from "yup";
export const loginValidation = () => {
    let loginForm = Yup.object().shape({
        email: Yup.string().required().email().label("Email"),
        password: Yup.string().required().label("Password"),
    });
    return loginForm;
};

export const resetPasswordValidation = () => {
    let passwordReset = Yup.object().shape({
        password: Yup.string()
            .required()
            .matches(/\w*[a-z]\w*/, "Password must have a small letter")
            .matches(/\w*[A-Z]\w*/, "Password must have a capital letter")
            .matches(/\d/, "Password must have a number")
            .matches(/[@#$]/, "Password must have a @#$ character ")
            .min(8, ({ min }) => `Password must be at least ${min} characters`)
            .label("Password"),
        password_confirmation: Yup.string()
            .required()
            .oneOf([Yup.ref("password"), null], "Passwords must match")
            .label("Password Confirmation"),
    });
    return passwordReset;
};
