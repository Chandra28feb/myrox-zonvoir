import * as Yup from "yup";
export const signUpValidations = () => {
    // const phoneRegex = RegExp(
    //     /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/
    // );
    let registration = Yup.object().shape({
        first_name: Yup.string()
            .required("First Name is required")
            .matches(/^(?!.*\^)[a-zA-Z]+$/, "Only alphabets allowed"),
        last_name: Yup.string()
            .required("Last Name is required")
            .matches(/^(?!.*\^)[a-zA-Z]+$/, "Only alphabets allowed"),
        email: Yup.string()
            .required("Email is required")
            .email()
            .label("Email"),
        password: Yup.string()
            .required()
            .matches(/\w*[a-z]\w*/, "Password must have a lowercase letter")
            .matches(/\w*[A-Z]\w*/, "Password must have a uppercase letter")
            .matches(/\d/, "Password must have a number")
            .matches(/[@#$]/, "Password must have a @#$ character")
            .min(8, ({ min }) => `Password must be at least ${min} characters`)
            .label("Password"),
        password_confirmation: Yup.string()
            .required()
            .oneOf([Yup.ref("password"), null], "Password must match")
            .label("Password Confirmation"),
        mobile_no: Yup.string().required("Phone number is required"),
        terms_and_conditions: Yup.string().required(
            "Please accept our terms and conditions/policy"
        ),
        referred_by: Yup.string().label("How did you hear about MYO?"),
    });
    return registration;
};
