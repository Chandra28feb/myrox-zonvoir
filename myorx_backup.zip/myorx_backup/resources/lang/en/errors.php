<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'authentication_failed'   => [
        'message' => 'This is not a registered user.',
    ],
    'unauthorized'   => [
        'message' => 'User unauthorized.',
    ],
    'server_error'=> 'internal server error.',
    'auth_token_expired'=> 'Authentication token expired.',
    'email' => [
        'invalid_verification_code' => 'invalid email verification code.'
    ],
    'validation'=> [
        'phone_number_invalid' => 'The value provided is not a valid phone number.'
    ],
    'validation_failed'   => [
        'message' => 'All fields fill mandatory',
    ],
    'invalid_credentials'   => [
        'message' => 'User id or password is incorrect',
    ],
    'validation_failed_mobile'   => [
        'message' => 'Enter mobile number',
    ],
    'validation_failed_email'   => [
        'message' => 'Enter email address',
    ],
];
