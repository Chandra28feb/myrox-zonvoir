<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */
    'phone_otp' => [
        'send'           =>  'Otp Send successfully.',
        'not_send'       =>  'Otp not send.',
        'phone_verified'   =>  'Phone number verified successfully.',
        'invalid_code'      =>  'Invalid verification code entered!',
        'expired_code'      =>  'Verification code was incorrect/expired!',
    ],
    'email' => [
        'verified' => 'Email verified successfully',
        'not_verified' => 'Email not verified'
    ]



];
