<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'authentication_success' =>  'User authenticated successfully.',
    'auth_token_valid'       =>  'Token Verification validated successfully.',
    'email_process'          =>  'Email Processed.',
    'email_not_process'      => 'Email failed.',
    'user_logout_success'    => 'Logout successfully',
    'user_logout_failed'     => 'Logout failed',
    'user_unauthenticated'    => 'User not authenticated',
    'email_change_success'    => 'Email successfully changed',
    'email_change_failed'    => 'Email has not been change try after some time',
    'email_change_limit_breach' => 'Limit breach ! You can change email only one time',
    'phone_change_success'    => 'Phone number successfully changed',
    'phone_change_limit_breach' => 'Limit breach ! You can change mobile number only one time',
    'phone_change_limit_error' => 'Some thing went wrong please try after some time',
    'reset_link_send'         => 'Reset password link has been send to your email address',
];
