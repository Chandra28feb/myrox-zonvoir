<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email OTP</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800&display=swap" rel="stylesheet">

  <style>
      .u-row{width: 500px !important;}
 </style>

</head>

<body style="font-family: 'Poppins', sans-serif; background-color: #e7e7e7; margin: 0;">

   <div class="u-row" style="Margin: 0 auto;min-width: 320px;max-width: 500px;overflow-wrap: break-word;word-wrap: break-word;word-break: break-word;background-color: white;">

       <table width="100%" cellpadding="0" cellspacing="0" border="0">
           <thead style="background-color: #52137d;">
               <tr>
                   <th style="padding: 20px;">
                       <img src="https://myorx.zonvoirdemo.in/wp-content/themes/twenty-twenty-one-child/img/myoRX-logo-email.svg" alt="Image">
                   </th>
               </tr>
           </thead>
           <tbody>
               <tr>
                   <td style="padding: 20px 20px 20px 20px">
                       <table width="100%" cellpadding="0" cellspacing="0" border="0">
                           <tr>
                              <td>
                                  <h3 style="font-family: 'Poppins';font-style: normal;font-weight: 600;font-size: 30px;line-height: 40px;margin-bottom: 10px;margin-top: 0;text-align: center;"> Email Confirmation </h3>
                              </td>
                          </tr>

                          <tr>
                              <td><p style="font-weight: 400;font-size: 14px;line-height: 24px;margin-bottom: 10px;">Hi, {{Firstname}} {{Lastname}}</p></td>
                          </tr>

                          <tr>
                              <td>
                                  <p style="font-family: 'Poppins';font-style: normal;font-weight: 400;font-size: 15px;line-height: 25px;color: #000000;margin-bottom: 10px; text-align: justify;">You are just a step away from accessing your myoRX account. Use the following verification code to complete your Registration procedure. <b>The code is valid for 30 minutes only.</b></p>

                                   <p style="font-family: 'Poppins';font-style: normal;font-weight: 400;font-size: 15px;line-height: 25px;color: #000000; text-align: justify;">Your 6 digits verification code is below:</p>
                              </td>
                          </tr>



                          <tr>
                              <th>
                                   <h1 style="color: #52137D;font-weight: 500;font-size: 40px; text-align: center;    margin: 10px;">{{$code ?? ''}}</h1>
                              </th>
                          </tr>

                           <tr>
                              <td>
                                  <p style="font-family: 'Poppins';font-style: normal;font-weight: 400;font-size: 13px;line-height: 24px;color: #000000;margin-top: 0px; text-align: justify;">If you don't recognize or expect this email, you can always report suspicious behaviour to our <a href="mailto:support@mindyourownrx.com" style="color: #52137D;">support team</a>.</p>
                              </td>
                          </tr>
                       </table>
                   </td>
               </tr>
           </tbody>

              <tfoot>
               <tr>
                   <td style="padding: 20px 20px 20px 20px; background: #52137D;">
                       <table width="100%" cellpadding="0" cellspacing="0" border="0">
                           <tr>
                               <td>

                                  <p style="font-weight: 400;font-size: 14px; margin: 0px 0px 3px 0px;text-align: center;color: #FFFFFF;">myoRX</p>
                                   <p style="font-weight: 400;font-size: 14px; margin: 2px 0px 10px 0px;text-align: center;color: #FFFFFF;">12345 SW 65th Court Suite, Honolulu, Hawaii, 12345</p>
                                   <p style="font-weight: 400;font-size: 14px;margin: 0px 0px 3px 0px;text-align: center;color: #FFFFFF;">© myoRx. All rights reserved.</p>
                                   <hr style="max-width: 100%;">

                                    <p style="font-weight: 500;font-size: 10px;margin: 5px 0px 3px 0px;text-align: center;color: #FFFFFF;">This email was sent from a notification-only address that cannot accept incoming email.</p>
                               </td>
                           </tr>

                       </table>
                   </td>
               </tr>
               </tfoot>
       </table>

   </div>

</body>


</html>
