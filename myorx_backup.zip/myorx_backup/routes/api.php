<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\API\AuthController;
use App\Http\Controllers\API\UserController;
use App\Http\Controllers\API\MessagesController;
use App\Http\Controllers\API\RegisterController;
use App\Http\Controllers\API\ResetPasswordController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/
Route::group(['prefix' => 'v1'], function () {
    Route::post('signup',[RegisterController::class, 'signup']);
    Route::post('login', [AuthController::class, 'login']);
    Route::post('forgot-password', [ResetPasswordController::class, 'forgetPassword']);
    Route::post('reset-password', [ResetPasswordController::class, 'resetPassword'])->name('password.update');
    Route::middleware('auth:sanctum')->group(function () {
        Route::get('verify-token', [AuthController::class, 'verifyToken']);
        Route::get('send-otp', [MessagesController::class, 'sendOtpMessage'])->middleware('throttle:auth_otp_limit');
        Route::post('sms-otp-verification', [MessagesController::class, 'otpVerify']);
        Route::get('send-verification-email', [MessagesController::class, 'sendEmailMessage'])->middleware('throttle:auth_otp_limit');
        Route::post('email-otp-verification', [MessagesController::class, 'emailVerify']);
        Route::get('logout', [AuthController::class,'logout']);
        Route::post('change-mobile-number',[UserController::class,'changeMobileNumber'])->middleware('changeMobileNumber');
        Route::post('change-email-address',[UserController::class,'changeEmailAddress'])->middleware('changeEmailAddress');
    });
});
